# Demo 2 : Fonctionnalités Natives iOS

## 📋 Sommaire

1. [Biométrie (Face ID / Touch ID)](#1-biométrie-face-id--touch-id)
2. [Appels Téléphoniques](#2-appels-téléphoniques)
3. [Notifications Push](#3-notifications-push)

---

## 1. Biométrie (Face ID / Touch ID)

### Concept

iOS permet d'authentifier l'utilisateur via **Face ID** (reconnaissance faciale) ou **Touch ID** (empreinte digitale) grâce au framework `LocalAuthentication`.

### Import

```swift
import LocalAuthentication
```

### Implémentation

```swift
class BiometricManager {
    private let context = LAContext()

    // Vérifier si la biométrie est disponible
    func canUseBiometric() -> Bool {
        var error: NSError?
        return context.canEvaluatePolicy(
            .deviceOwnerAuthenticationWithBiometrics,
            error: &error
        )
    }

    // Déterminer le type de biométrie
    func getBiometricType() -> String {
        switch context.biometryType {
        case .faceID:
            return "Face ID"
        case .touchID:
            return "Touch ID"
        case .none:
            return "Non disponible"
        @unknown default:
            return "Inconnu"
        }
    }

    // Authentifier l'utilisateur
    func authenticate(completion: @escaping (Bool, String) -> Void) {
        let reason = "Authentification requise"

        context.evaluatePolicy(
            .deviceOwnerAuthenticationWithBiometrics,
            localizedReason: reason
        ) { success, error in
            DispatchQueue.main.async {
                if success {
                    completion(true, "Authentification réussie")
                } else {
                    let message = self.handleError(error as? LAError)
                    completion(false, message)
                }
            }
        }
    }

    // Gérer les erreurs
    private func handleError(_ error: LAError?) -> String {
        guard let error = error else { return "Erreur inconnue" }

        switch error.code {
        case .authenticationFailed:
            return "Échec de l'authentification"
        case .userCancel:
            return "Annulé par l'utilisateur"
        case .userFallback:
            return "Fallback vers mot de passe"
        case .biometryNotAvailable:
            return "Biométrie non disponible"
        case .biometryNotEnrolled:
            return "Biométrie non configurée"
        case .biometryLockout:
            return "Trop de tentatives"
        default:
            return error.localizedDescription
        }
    }
}
```

### Configuration Info.plist

**Obligatoire** pour Face ID :

```xml
<key>NSFaceIDUsageDescription</key>
<string>Authentification requise pour accéder à l'application</string>
```

### Points clés

| Élément             | Rôle                                         |
| ------------------- | -------------------------------------------- |
| `LAContext`         | Contexte d'authentification                  |
| `canEvaluatePolicy` | Vérifier si la biométrie est disponible      |
| `biometryType`      | Type de biométrie (.faceID, .touchID, .none) |
| `evaluatePolicy`    | Lancer l'authentification                    |
| `LAError`           | Énumération des erreurs possibles            |

### Policies disponibles

| Policy                                     | Description                   |
| ------------------------------------------ | ----------------------------- |
| `.deviceOwnerAuthenticationWithBiometrics` | Biométrie uniquement          |
| `.deviceOwnerAuthentication`               | Biométrie + fallback code PIN |

### Gestion des erreurs

| Code                    | Signification                               |
| ----------------------- | ------------------------------------------- |
| `.authenticationFailed` | Biométrie non reconnue                      |
| `.userCancel`           | L'utilisateur a annulé                      |
| `.userFallback`         | L'utilisateur veut utiliser le mot de passe |
| `.biometryNotAvailable` | Pas de capteur biométrique                  |
| `.biometryNotEnrolled`  | Aucune empreinte/visage enregistré          |
| `.biometryLockout`      | Trop de tentatives échouées                 |

### Test sur Simulateur

1. **Features** → **Face ID** → **Enrolled**
2. Pour simuler un succès : **Features** → **Face ID** → **Matching Face**
3. Pour simuler un échec : **Features** → **Face ID** → **Non-matching Face**

---

## 2. Appels Téléphoniques

### Concept

iOS permet de déclencher des appels via des **URL Schemes**. L'app ouvre l'URL et iOS gère le reste.

### URL Schemes disponibles

| Scheme              | Comportement                            |
| ------------------- | --------------------------------------- |
| `tel://`            | Appel direct (compose immédiatement)    |
| `telprompt://`      | Appel avec confirmation (demande avant) |
| `facetime://`       | Appel FaceTime vidéo                    |
| `facetime-audio://` | Appel FaceTime audio                    |

### Implémentation

```swift
class PhoneCallManager {

    // Appel direct (sans confirmation)
    func makeDirectCall(phoneNumber: String) {
        call(scheme: "tel", number: phoneNumber)
    }

    // Appel avec confirmation
    func makeCallWithPrompt(phoneNumber: String) {
        call(scheme: "telprompt", number: phoneNumber)
    }

    // Appel FaceTime
    func makeFaceTimeCall(phoneNumber: String) {
        call(scheme: "facetime", number: phoneNumber)
    }

    private func call(scheme: String, number: String) {
        // Nettoyer le numéro (garder uniquement les chiffres)
        let cleanNumber = number.components(
            separatedBy: CharacterSet.decimalDigits.inverted
        ).joined()

        guard !cleanNumber.isEmpty else {
            print("❌ Numéro invalide")
            return
        }

        // Construire l'URL
        guard let url = URL(string: "\(scheme)://\(cleanNumber)") else {
            print("❌ Impossible de créer l'URL")
            return
        }

        // Vérifier si l'appareil peut passer des appels
        guard UIApplication.shared.canOpenURL(url) else {
            print("❌ Cet appareil ne peut pas passer d'appels")
            return
        }

        // Ouvrir l'URL (déclenche l'appel)
        UIApplication.shared.open(url) { success in
            if success {
                print("✅ Appel lancé")
            } else {
                print("❌ Échec du lancement")
            }
        }
    }
}
```

### Points clés

| Élément                       | Rôle                              |
| ----------------------------- | --------------------------------- |
| `URL(string:)`                | Créer l'URL avec le scheme        |
| `canOpenURL()`                | Vérifier si l'action est possible |
| `UIApplication.shared.open()` | Ouvrir l'URL (déclenche l'action) |

### Configuration Info.plist (optionnel)

Pour vérifier `canOpenURL` :

```xml
<key>LSApplicationQueriesSchemes</key>
<array>
    <string>tel</string>
    <string>telprompt</string>
    <string>facetime</string>
    <string>facetime-audio</string>
</array>
```

### ⚠️ Limitations

- **Simulateur** : Ne peut pas passer d'appels (testé sur appareil réel uniquement)
- **iPad WiFi** : Pas de capacité téléphonique (sauf Handoff)
- **tel://** : Compose immédiatement sans confirmation ⚠️

### Exemple d'utilisation

```swift
// Bouton d'appel
Button("Appeler le support") {
    PhoneCallManager().makeCallWithPrompt(phoneNumber: "0123456789")
}

// Lien mailto (bonus)
if let url = URL(string: "mailto:support@example.com") {
    UIApplication.shared.open(url)
}
```

---

## 3. Notifications Push

### Concept

Les **notifications locales** sont créées et programmées par l'app elle-même (pas de serveur). Elles utilisent le framework `UserNotifications`.

### Import

```swift
import UserNotifications
```

### Étape 1 : Demander la permission

```swift
func requestPermission() {
    let center = UNUserNotificationCenter.current()

    center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
        DispatchQueue.main.async {
            if granted {
                print("✅ Permission accordée")
            } else {
                print("❌ Permission refusée")
            }
        }
    }
}
```

### Étape 2 : Vérifier le statut

```swift
func checkAuthorizationStatus() {
    UNUserNotificationCenter.current().getNotificationSettings { settings in
        switch settings.authorizationStatus {
        case .authorized:
            print("✅ Autorisé")
        case .denied:
            print("❌ Refusé")
        case .notDetermined:
            print("⚠️ Non demandé")
        case .provisional:
            print("⚠️ Provisoire")
        case .ephemeral:
            print("⚠️ Éphémère")
        @unknown default:
            print("❓ Inconnu")
        }
    }
}
```

### Étape 3 : Créer une notification

```swift
func sendNotification() {
    // 1. Créer le contenu
    let content = UNMutableNotificationContent()
    content.title = "Titre de la notification"
    content.body = "Corps du message"
    content.sound = .default
    content.badge = 1

    // 2. Créer le trigger (déclencheur)
    // Option A: Immédiat (trigger = nil)
    // Option B: Après un délai
    let trigger = UNTimeIntervalNotificationTrigger(
        timeInterval: 5,  // 5 secondes
        repeats: false
    )

    // 3. Créer la requête
    let request = UNNotificationRequest(
        identifier: UUID().uuidString,
        content: content,
        trigger: trigger  // nil = immédiat
    )

    // 4. Programmer la notification
    UNUserNotificationCenter.current().add(request) { error in
        if let error = error {
            print("❌ Erreur: \(error.localizedDescription)")
        } else {
            print("✅ Notification programmée")
        }
    }
}
```

### Types de Triggers

| Trigger                             | Description                   |
| ----------------------------------- | ----------------------------- |
| `nil`                               | Immédiat                      |
| `UNTimeIntervalNotificationTrigger` | Après X secondes              |
| `UNCalendarNotificationTrigger`     | À une date/heure précise      |
| `UNLocationNotificationTrigger`     | En entrant/sortant d'une zone |

### Exemple : Notification à une date précise

```swift
// Notification tous les jours à 9h00
var dateComponents = DateComponents()
dateComponents.hour = 9
dateComponents.minute = 0

let trigger = UNCalendarNotificationTrigger(
    dateMatching: dateComponents,
    repeats: true
)
```

### Notifications avec Actions

```swift
func setupNotificationActions() {
    // Créer les actions
    let likeAction = UNNotificationAction(
        identifier: "LIKE",
        title: "👍 J'aime",
        options: .foreground  // Ouvre l'app
    )

    let dismissAction = UNNotificationAction(
        identifier: "DISMISS",
        title: "Ignorer",
        options: .destructive
    )

    // Créer la catégorie
    let category = UNNotificationCategory(
        identifier: "ACTIONS_CATEGORY",
        actions: [likeAction, dismissAction],
        intentIdentifiers: [],
        options: []
    )

    // Enregistrer la catégorie
    UNUserNotificationCenter.current().setNotificationCategories([category])
}

// Utiliser la catégorie dans une notification
content.categoryIdentifier = "ACTIONS_CATEGORY"
```

### Recevoir les notifications (App au premier plan)

```swift
class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        return true
    }

    // Notification reçue quand l'app est au premier plan
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        // Afficher la notification même si l'app est ouverte
        completionHandler([.banner, .sound, .badge])
    }

    // L'utilisateur a interagi avec la notification
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse,
        withCompletionHandler completionHandler: @escaping () -> Void
    ) {
        let actionIdentifier = response.actionIdentifier

        switch actionIdentifier {
        case "LIKE":
            print("👍 L'utilisateur a aimé")
        case UNNotificationDefaultActionIdentifier:
            print("📱 Notification tapée")
        case UNNotificationDismissActionIdentifier:
            print("❌ Notification fermée")
        default:
            break
        }

        completionHandler()
    }
}
```

### Points clés

| Élément                            | Rôle                                |
| ---------------------------------- | ----------------------------------- |
| `UNUserNotificationCenter`         | Centre de gestion des notifications |
| `requestAuthorization`             | Demander la permission              |
| `UNMutableNotificationContent`     | Contenu de la notification          |
| `UNNotificationTrigger`            | Quand déclencher                    |
| `UNNotificationRequest`            | Requête complète                    |
| `UNUserNotificationCenterDelegate` | Recevoir les événements             |

### Annuler des notifications

```swift
let center = UNUserNotificationCenter.current()

// Annuler une notification spécifique
center.removePendingNotificationRequests(withIdentifiers: ["mon-id"])

// Annuler toutes les notifications en attente
center.removeAllPendingNotificationRequests()

// Supprimer les notifications affichées
center.removeAllDeliveredNotifications()
```

---

## 📊 Résumé

| Fonctionnalité | Framework             | Permission requise     |
| -------------- | --------------------- | ---------------------- |
| Biométrie      | `LocalAuthentication` | Info.plist (Face ID)   |
| Appels         | `UIKit` (URL Schemes) | Non                    |
| Notifications  | `UserNotifications`   | `requestAuthorization` |

---

## 🔧 Fichiers de la Demo

| Fichier                  | Description                  |
| ------------------------ | ---------------------------- |
| `Demo2App.swift`         | Point d'entrée + AppDelegate |
| `ContentView.swift`      | Menu de navigation           |
| `BiometricView.swift`    | Demo biométrie               |
| `PhoneCallView.swift`    | Demo appels                  |
| `NotificationView.swift` | Demo notifications           |

---

## ✅ Checklist de la Demo

### Biométrie

- [ ] Vérifier si la biométrie est disponible
- [ ] Afficher le type (Face ID / Touch ID)
- [ ] Authentifier l'utilisateur
- [ ] Gérer les erreurs (annulation, échec, lockout)

### Appels

- [ ] Appel direct (`tel://`)
- [ ] Appel avec confirmation (`telprompt://`)
- [ ] FaceTime (`facetime://`)
- [ ] Gérer les appareils sans téléphone

### Notifications

- [ ] Demander la permission
- [ ] Afficher le statut d'autorisation
- [ ] Envoyer une notification immédiate
- [ ] Programmer une notification différée
- [ ] Ajouter des actions interactives
- [ ] Recevoir les notifications au premier plan

---

## 📚 Ressources

- [LocalAuthentication - Apple](https://developer.apple.com/documentation/localauthentication)
- [UserNotifications - Apple](https://developer.apple.com/documentation/usernotifications)
- [URL Schemes - Apple](https://developer.apple.com/documentation/uikit/inter-process_communication/allowing_apps_and_websites_to_link_to_your_content)
