//
//  DEMO2Tests.swift
//  DEMO2Tests
//
//  Created by Rayan Mechety on 09/12/2025.
//

import Testing
@testable import DEMO2

struct DEMO2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
