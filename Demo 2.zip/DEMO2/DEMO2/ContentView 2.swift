import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("DEMO 2: Fonctionnalités iOS Natives").font(.title3).bold()) {

                    NavigationLink(destination: BiometricView()) {
                        Label("Biométrie (Face ID / Touch ID)", systemImage: "faceid")
                            .foregroundColor(.blue)
                    }

                    NavigationLink(destination: PhoneCallView()) {
                        Label("Appels Téléphoniques", systemImage: "phone.fill")
                            .foregroundColor(.green)
                    }

                    NavigationLink(destination: NotificationView()) {
                        Label("Notifications Push", systemImage: "bell.badge.fill")
                            .foregroundColor(.orange)
                    }
                }
            }
            .navigationTitle("Fonctionnalités iOS")
        }
    }
}
