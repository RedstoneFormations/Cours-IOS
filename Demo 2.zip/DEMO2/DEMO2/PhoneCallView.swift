import SwiftUI

struct PhoneCallView: View {
    @StateObject private var phoneManager = PhoneCallManager()

    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "phone.circle.fill")
                .font(.system(size: 80))
                .foregroundColor(.green)

            Text("Appels Téléphoniques")
                .font(.title2)
                .bold()

            VStack(spacing: 15) {
                PhoneButton(
                    title: "Appel Direct",
                    icon: "phone.fill",
                    color: .green,
                    description: "Compose immédiatement"
                ) {
                    phoneManager.makeDirectCall()
                }

                PhoneButton(
                    title: "Appel avec Confirmation",
                    icon: "phone.badge.checkmark",
                    color: .blue,
                    description: "Demande confirmation avant"
                ) {
                    phoneManager.makeCallWithPrompt()
                }

                PhoneButton(
                    title: "Ouvrir FaceTime",
                    icon: "video.fill",
                    color: .purple,
                    description: "Lance FaceTime"
                ) {
                    phoneManager.openFaceTime()
                }
            }
            .padding()

            // Zone de numéro de téléphone
            VStack(alignment: .leading, spacing: 10) {
                Text("Numéro de test:")
                    .font(.headline)
                TextField("Numéro", text: $phoneManager.phoneNumber)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .keyboardType(.phonePad)
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)

            if !phoneManager.statusMessage.isEmpty {
                Text(phoneManager.statusMessage)
                    .font(.caption)
                    .foregroundColor(phoneManager.isError ? .red : .green)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(phoneManager.isError ? Color.red.opacity(0.1) : Color.green.opacity(0.1))
                    .cornerRadius(8)
            }

            Spacer()
        }
        .padding()
        .navigationTitle("Appels")
    }
}

// MARK: - PhoneCallManager
class PhoneCallManager: ObservableObject {
    @Published var phoneNumber = "0123456789"
    @Published var statusMessage = ""
    @Published var isError = false

    private let callTypes: [String: String] = [
        "tel": "Appel direct",
        "telprompt": "Appel avec confirmation",
        "facetime": "FaceTime audio",
        "facetime-audio": "FaceTime audio"
    ]

    func makeDirectCall() {
        makeCall(scheme: "tel")
    }

    func makeCallWithPrompt() {
        makeCall(scheme: "telprompt")
    }

    func openFaceTime() {
        makeCall(scheme: "facetime")
    }

    private func makeCall(scheme: String) {
        let cleanNumber = phoneNumber.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()

        guard !cleanNumber.isEmpty else {
            showError("Numéro invalide")
            return
        }

        guard let url = URL(string: "\(scheme)://\(cleanNumber)") else {
            showError("Impossible de créer l'URL d'appel")
            return
        }

        guard UIApplication.shared.canOpenURL(url) else {
            showError("Impossible d'effectuer des appels sur cet appareil")
            return
        }

        UIApplication.shared.open(url) { [weak self] success in
            DispatchQueue.main.async {
                if success {
                    self?.showSuccess("Appel lancé vers \(cleanNumber)")
                } else {
                    self?.showError("Échec du lancement de l'appel")
                }
            }
        }
    }

    private func showError(_ message: String) {
        statusMessage = "❌ \(message)"
        isError = true
    }

    private func showSuccess(_ message: String) {
        statusMessage = "✅ \(message)"
        isError = false
    }
}

// MARK: - PhoneButton
struct PhoneButton: View {
    let title: String
    let icon: String
    let color: Color
    let description: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .font(.title3)
                    .frame(width: 30)

                VStack(alignment: .leading) {
                    Text(title)
                        .font(.headline)
                    Text(description)
                        .font(.caption)
                        .foregroundColor(.gray)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding()
            .background(color.opacity(0.1))
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(color, lineWidth: 1)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}
