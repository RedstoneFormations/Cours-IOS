import SwiftUI
import LocalAuthentication

struct BiometricView: View {
    @StateObject private var biometricManager = BiometricManager()

    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: biometricManager.biometricType.icon)
                .font(.system(size: 80))
                .foregroundColor(.blue)

            Text("Authentification Biométrique")
                .font(.title2)
                .bold()

            VStack(alignment: .leading, spacing: 10) {
                InfoRow(label: "Type disponible", value: biometricManager.biometricType.rawValue)
                InfoRow(label: "Status", value: biometricManager.authenticationStatus)
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)

            if biometricManager.isAuthenticated {
                VStack {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 60))
                        .foregroundColor(.green)
                    Text("Authentification réussie!")
                        .font(.headline)
                        .foregroundColor(.green)
                }
                .padding()
            }

            Button(action: {
                biometricManager.authenticate()
            }) {
                Label("Authentifier", systemImage: "lock.open.fill")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .disabled(!biometricManager.canUseBiometric)

            if !biometricManager.canUseBiometric {
                Text("⚠️ Biométrie non disponible sur cet appareil")
                    .font(.caption)
                    .foregroundColor(.red)
            }

            Spacer()
        }
        .padding()
        .navigationTitle("Biométrie")
    }
}

// MARK: - BiometricManager
class BiometricManager: ObservableObject {
    @Published var isAuthenticated = false
    @Published var authenticationStatus = "Non authentifié"
    @Published var canUseBiometric = false
    @Published var biometricType: BiometricType = .none

    private let context = LAContext()

    enum BiometricType: String {
        case faceID = "Face ID"
        case touchID = "Touch ID"
        case none = "Non disponible"

        var icon: String {
            switch self {
            case .faceID: return "faceid"
            case .touchID: return "touchid"
            case .none: return "xmark.circle"
            }
        }
    }

    init() {
        checkBiometricAvailability()
    }

    private func checkBiometricAvailability() {
        var error: NSError?
        canUseBiometric = context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)

        if canUseBiometric {
            switch context.biometryType {
            case .faceID:
                biometricType = .faceID
            case .touchID:
                biometricType = .touchID
            default:
                biometricType = .none
            }
        } else {
            authenticationStatus = error?.localizedDescription ?? "Erreur inconnue"
        }
    }

    func authenticate() {
        let reason = "Authentification requise pour accéder à cette fonctionnalité"

        context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { [weak self] success, error in
            DispatchQueue.main.async {
                if success {
                    self?.isAuthenticated = true
                    self?.authenticationStatus = "✅ Authentifié avec succès"
                } else {
                    self?.isAuthenticated = false
                    if let error = error as? LAError {
                        self?.authenticationStatus = self?.handleAuthError(error) ?? "Erreur"
                    }
                }
            }
        }
    }

    private func handleAuthError(_ error: LAError) -> String {
        switch error.code {
        case .authenticationFailed:
            return "❌ Échec de l'authentification"
        case .userCancel:
            return "⚠️ Annulé par l'utilisateur"
        case .userFallback:
            return "🔑 Fallback vers mot de passe"
        case .biometryNotAvailable:
            return "❌ Biométrie non disponible"
        case .biometryNotEnrolled:
            return "❌ Biométrie non configurée"
        case .biometryLockout:
            return "🔒 Trop de tentatives"
        default:
            return "❌ Erreur: \(error.localizedDescription)"
        }
    }
}

// MARK: - Helper Views
struct InfoRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.gray)
            Spacer()
            Text(value)
                .font(.subheadline)
                .bold()
        }
    }
}
