import SwiftUI
import UserNotifications

struct NotificationView: View {
    @StateObject private var notificationManager = NotificationManager()

    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "bell.badge.fill")
                .font(.system(size: 80))
                .foregroundColor(.orange)

            Text("Notifications Push")
                .font(.title2)
                .bold()

            VStack(alignment: .leading, spacing: 10) {
                InfoRow(label: "Autorisation", value: notificationManager.authorizationStatus)
                InfoRow(label: "Notifications envoyées", value: "\(notificationManager.sentCount)")
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)

            // Afficher le bouton si permission non accordée (nil ou false)
            if notificationManager.permissionGranted != true {
                Button(action: {
                    notificationManager.requestPermission()
                }) {
                    Label("Demander l'autorisation", systemImage: "bell.badge")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.orange)
                        .cornerRadius(10)
                }
            }

            // Afficher les boutons de notification si permission accordée
            if notificationManager.permissionGranted == true {
                VStack(spacing: 15) {
                    NotificationButton(
                        title: "Notification Immédiate",
                        icon: "bell.fill",
                        color: .blue
                    ) {
                        notificationManager.sendImmediateNotification()
                    }

                    NotificationButton(
                        title: "Notification dans 5s",
                        icon: "clock.fill",
                        color: .green
                    ) {
                        notificationManager.scheduleNotification(delay: 5)
                    }

                    NotificationButton(
                        title: "Notification avec Actions",
                        icon: "hand.tap.fill",
                        color: .purple
                    ) {
                        notificationManager.sendNotificationWithActions()
                    }

                    NotificationButton(
                        title: "Annuler Notifications",
                        icon: "xmark.circle.fill",
                        color: .red
                    ) {
                        notificationManager.cancelAllNotifications()
                    }
                }
            }

            if !notificationManager.lastMessage.isEmpty {
                Text(notificationManager.lastMessage)
                    .font(.caption)
                    .foregroundColor(.green)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.1))
                    .cornerRadius(8)
            }

            Spacer()
        }
        .padding()
        .navigationTitle("Notifications")
        .onAppear {
            notificationManager.checkAuthorizationStatus()
        }
    }
}

// MARK: - NotificationManager
class NotificationManager: ObservableObject {
    @Published var permissionGranted: Bool?
    @Published var authorizationStatus = "Non demandée"
    @Published var lastMessage = ""
    @Published var sentCount = 0

    private let notificationCenter = UNUserNotificationCenter.current()

    func checkAuthorizationStatus() {
        notificationCenter.getNotificationSettings { [weak self] settings in
            DispatchQueue.main.async {
                switch settings.authorizationStatus {
                case .authorized:
                    self?.permissionGranted = true
                    self?.authorizationStatus = "✅ Autorisée"
                case .denied:
                    self?.permissionGranted = false
                    self?.authorizationStatus = "❌ Refusée"
                case .notDetermined:
                    self?.permissionGranted = nil
                    self?.authorizationStatus = "⚠️ Non demandée"
                case .provisional:
                    self?.permissionGranted = true
                    self?.authorizationStatus = "⚠️ Provisoire"
                case .ephemeral:
                    self?.permissionGranted = true
                    self?.authorizationStatus = "⚠️ Éphémère"
                @unknown default:
                    self?.permissionGranted = nil
                    self?.authorizationStatus = "❓ Inconnu"
                }
            }
        }
    }

    func requestPermission() {
        notificationCenter.requestAuthorization(options: [.alert, .sound, .badge]) { [weak self] granted, error in
            DispatchQueue.main.async {
                self?.permissionGranted = granted
                self?.authorizationStatus = granted ? "✅ Autorisée" : "❌ Refusée"

                if granted {
                    self?.lastMessage = "Permission accordée!"
                    self?.setupNotificationCategories()
                } else if let error = error {
                    self?.lastMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }

    func sendImmediateNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Notification immédiate"
        content.body = "Ceci est une notification de test"
        content.sound = .default
        content.badge = NSNumber(value: sentCount + 1)

        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: nil // nil = immédiat
        )

        scheduleNotificationRequest(request)
    }

    func scheduleNotification(delay: TimeInterval) {
        let content = UNMutableNotificationContent()
        content.title = "Notification programmée"
        content.body = "Envoyée après \(Int(delay)) secondes"
        content.sound = .default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: delay, repeats: false)
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: trigger
        )

        scheduleNotificationRequest(request)
        lastMessage = "⏰ Notification programmée dans \(Int(delay))s"
    }

    func sendNotificationWithActions() {
        let content = UNMutableNotificationContent()
        content.title = "Notification Interactive"
        content.body = "Appuyez pour répondre"
        content.sound = .default
        content.categoryIdentifier = "ACTION_CATEGORY"

        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: nil
        )

        scheduleNotificationRequest(request)
    }

    func cancelAllNotifications() {
        notificationCenter.removeAllPendingNotificationRequests()
        notificationCenter.removeAllDeliveredNotifications()
        lastMessage = "🗑️ Toutes les notifications annulées"
        sentCount = 0
    }

    private func scheduleNotificationRequest(_ request: UNNotificationRequest) {
        notificationCenter.add(request) { [weak self] error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.lastMessage = "❌ Erreur: \(error.localizedDescription)"
                } else {
                    self?.sentCount += 1
                    if request.trigger == nil {
                        self?.lastMessage = "✅ Notification envoyée!"
                    }
                }
            }
        }
    }

    private func setupNotificationCategories() {
        let likeAction = UNNotificationAction(
            identifier: "LIKE_ACTION",
            title: "👍 J'aime",
            options: .foreground
        )

        let dislikeAction = UNNotificationAction(
            identifier: "DISLIKE_ACTION",
            title: "👎 Je n'aime pas",
            options: []
        )

        let category = UNNotificationCategory(
            identifier: "ACTION_CATEGORY",
            actions: [likeAction, dislikeAction],
            intentIdentifiers: [],
            options: []
        )

        notificationCenter.setNotificationCategories([category])
    }
}

// MARK: - NotificationButton
struct NotificationButton: View {
    let title: String
    let icon: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(color)
                .cornerRadius(10)
        }
    }
}
