# Demo 3 : Fichiers & Sécurité

## 📋 Sommaire

1. [Upload et Download de Fichiers](#1-upload-et-download-de-fichiers)
2. [Photos & Galerie](#2-photos--galerie)
3. [Gestion des PDF](#3-gestion-des-pdf)
4. [Empêcher la Capture d'Écran](#4-empêcher-la-capture-décran)
5. [Build iOS](#5-build-ios)

---

## 1. Upload et Download de Fichiers

### Concept

iOS fournit un système de fichiers sandboxé. Chaque app a son propre espace de stockage isolé. On utilise `FileManager` pour les opérations locales et `UIDocumentPickerViewController` pour l'import/export.

### Répertoires disponibles

| Répertoire       | Usage                            | Sauvegardé iCloud |
| ---------------- | -------------------------------- | ----------------- |
| `Documents`      | Fichiers créés par l'utilisateur | ✅ Oui            |
| `Library/Caches` | Fichiers temporaires recreables  | ❌ Non            |
| `tmp`            | Fichiers très temporaires        | ❌ Non            |

### Obtenir le chemin des répertoires

```swift
// Répertoire Documents
let documentsPath = FileManager.default.urls(
    for: .documentDirectory,
    in: .userDomainMask
)[0]

// Répertoire Caches
let cachesPath = FileManager.default.urls(
    for: .cachesDirectory,
    in: .userDomainMask
)[0]

// Répertoire temporaire
let tmpPath = FileManager.default.temporaryDirectory
```

### Créer et écrire un fichier

```swift
func createTextFile(name: String, content: String) {
    let documentsPath = FileManager.default.urls(
        for: .documentDirectory,
        in: .userDomainMask
    )[0]

    let fileURL = documentsPath.appendingPathComponent(name)

    do {
        try content.write(to: fileURL, atomically: true, encoding: .utf8)
        print("✅ Fichier créé: \(fileURL.path)")
    } catch {
        print("❌ Erreur: \(error.localizedDescription)")
    }
}

// Utilisation
createTextFile(name: "notes.txt", content: "Contenu du fichier")
```

### Lire un fichier

```swift
func readTextFile(name: String) -> String? {
    let documentsPath = FileManager.default.urls(
        for: .documentDirectory,
        in: .userDomainMask
    )[0]

    let fileURL = documentsPath.appendingPathComponent(name)

    do {
        let content = try String(contentsOf: fileURL, encoding: .utf8)
        return content
    } catch {
        print("❌ Erreur de lecture: \(error.localizedDescription)")
        return nil
    }
}
```

### Lister les fichiers

```swift
func listFiles() -> [String] {
    let documentsPath = FileManager.default.urls(
        for: .documentDirectory,
        in: .userDomainMask
    )[0]

    do {
        let files = try FileManager.default.contentsOfDirectory(
            atPath: documentsPath.path
        )
        return files.sorted()
    } catch {
        print("❌ Erreur: \(error.localizedDescription)")
        return []
    }
}
```

### Supprimer un fichier

```swift
func deleteFile(name: String) {
    let documentsPath = FileManager.default.urls(
        for: .documentDirectory,
        in: .userDomainMask
    )[0]

    let fileURL = documentsPath.appendingPathComponent(name)

    do {
        try FileManager.default.removeItem(at: fileURL)
        print("✅ Fichier supprimé")
    } catch {
        print("❌ Erreur: \(error.localizedDescription)")
    }
}
```

### Vérifier si un fichier existe

```swift
func fileExists(name: String) -> Bool {
    let documentsPath = FileManager.default.urls(
        for: .documentDirectory,
        in: .userDomainMask
    )[0]

    let fileURL = documentsPath.appendingPathComponent(name)

    return FileManager.default.fileExists(atPath: fileURL.path)
}
```

### Import de fichiers (Document Picker)

```swift
import SwiftUI
import UniformTypeIdentifiers

struct DocumentPicker: UIViewControllerRepresentable {
    let onFilePicked: (URL) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // Types de fichiers acceptés
        let picker = UIDocumentPickerViewController(
            forOpeningContentTypes: [.item],  // Tous les fichiers
            asCopy: true  // Copier le fichier (pas juste une référence)
        )
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onFilePicked: onFilePicked)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onFilePicked: (URL) -> Void

        init(onFilePicked: @escaping (URL) -> Void) {
            self.onFilePicked = onFilePicked
        }

        func documentPicker(
            _ controller: UIDocumentPickerViewController,
            didPickDocumentsAt urls: [URL]
        ) {
            guard let url = urls.first else { return }
            onFilePicked(url)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            print("Sélection annulée")
        }
    }
}
```

### Utilisation du Document Picker

```swift
struct ContentView: View {
    @State private var showPicker = false

    var body: some View {
        Button("Importer un fichier") {
            showPicker = true
        }
        .sheet(isPresented: $showPicker) {
            DocumentPicker { url in
                handleImportedFile(url)
            }
        }
    }

    func handleImportedFile(_ url: URL) {
        let fileName = url.lastPathComponent
        let documentsPath = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        )[0]
        let destinationURL = documentsPath.appendingPathComponent(fileName)

        do {
            // Supprimer si existe déjà
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }
            // Copier le fichier
            try FileManager.default.copyItem(at: url, to: destinationURL)
            print("✅ Fichier importé: \(fileName)")
        } catch {
            print("❌ Erreur: \(error.localizedDescription)")
        }
    }
}
```

### Export / Partage de fichiers (Share Sheet)

```swift
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(
            activityItems: items,
            applicationActivities: nil
        )
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// Utilisation
struct ContentView: View {
    @State private var showShare = false

    var body: some View {
        Button("Partager") {
            showShare = true
        }
        .sheet(isPresented: $showShare) {
            let fileURL = getFileURL("mon-fichier.txt")
            ShareSheet(items: [fileURL])
        }
    }
}
```

### Téléchargement depuis une URL

```swift
func downloadFile(from urlString: String, completion: @escaping (URL?) -> Void) {
    guard let url = URL(string: urlString) else {
        completion(nil)
        return
    }

    let task = URLSession.shared.downloadTask(with: url) { tempURL, response, error in
        guard let tempURL = tempURL, error == nil else {
            DispatchQueue.main.async { completion(nil) }
            return
        }

        // Déplacer vers Documents
        let documentsPath = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        )[0]

        let fileName = url.lastPathComponent
        let destinationURL = documentsPath.appendingPathComponent(fileName)

        do {
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }
            try FileManager.default.moveItem(at: tempURL, to: destinationURL)
            DispatchQueue.main.async { completion(destinationURL) }
        } catch {
            DispatchQueue.main.async { completion(nil) }
        }
    }

    task.resume()
}
```

### Points clés

| Élément                          | Rôle                               |
| -------------------------------- | ---------------------------------- |
| `FileManager.default`            | Gestionnaire de fichiers singleton |
| `.documentDirectory`             | Répertoire Documents de l'app      |
| `appendingPathComponent`         | Construire un chemin de fichier    |
| `UIDocumentPickerViewController` | Sélecteur de fichiers système      |
| `UIActivityViewController`       | Share Sheet (partage)              |
| `URLSession.downloadTask`        | Télécharger un fichier             |

### Configuration Info.plist

Pour permettre le partage de fichiers via iTunes/Finder :

```xml
<key>UIFileSharingEnabled</key>
<true/>
<key>LSSupportsOpeningDocumentsInPlace</key>
<true/>
```

---

## 2. Photos & Galerie

### Concept

iOS propose plusieurs façons d'accéder aux photos :

- **PhotosPicker** (iOS 16+) : Sélecteur moderne intégré à SwiftUI
- **UIImagePickerController** : Ancien sélecteur (caméra + galerie)
- **PHPhotoLibrary** : Accès direct à la librairie Photos

### PhotosPicker (iOS 16+ - Recommandé)

```swift
import SwiftUI
import PhotosUI

struct PhotoGalleryView: View {
    @State private var selectedItem: PhotosPickerItem?
    @State private var selectedImage: UIImage?

    var body: some View {
        VStack {
            // Bouton de sélection
            PhotosPicker(
                selection: $selectedItem,
                matching: .images,          // Filtre: images seulement
                photoLibrary: .shared()
            ) {
                Label("Ouvrir la Galerie", systemImage: "photo.stack")
            }

            // Afficher l'image sélectionnée
            if let image = selectedImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
            }
        }
        .onChange(of: selectedItem) { newItem in
            loadImage(from: newItem)
        }
    }

    func loadImage(from item: PhotosPickerItem?) {
        guard let item = item else { return }

        item.loadTransferable(type: Data.self) { result in
            DispatchQueue.main.async {
                if case .success(let data) = result,
                   let data = data,
                   let image = UIImage(data: data) {
                    selectedImage = image
                }
            }
        }
    }
}
```

### Sélection multiple

```swift
struct MultiplePhotosView: View {
    @State private var selectedItems: [PhotosPickerItem] = []
    @State private var selectedImages: [UIImage] = []

    var body: some View {
        VStack {
            PhotosPicker(
                selection: $selectedItems,
                maxSelectionCount: 5,        // Maximum 5 images
                matching: .images,
                photoLibrary: .shared()
            ) {
                Label("Sélectionner plusieurs photos", systemImage: "photo.on.rectangle")
            }

            ScrollView(.horizontal) {
                HStack {
                    ForEach(selectedImages.indices, id: \.self) { index in
                        Image(uiImage: selectedImages[index])
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                }
            }
        }
        .onChange(of: selectedItems) { _ in
            loadImages()
        }
    }

    func loadImages() {
        selectedImages = []

        for item in selectedItems {
            item.loadTransferable(type: Data.self) { result in
                DispatchQueue.main.async {
                    if case .success(let data) = result,
                       let data = data,
                       let image = UIImage(data: data) {
                        selectedImages.append(image)
                    }
                }
            }
        }
    }
}
```

### Filtres disponibles pour PhotosPicker

| Filtre               | Description                |
| -------------------- | -------------------------- |
| `.images`            | Toutes les images          |
| `.videos`            | Toutes les vidéos          |
| `.livePhotos`        | Photos Live                |
| `.screenshots`       | Captures d'écran           |
| `.any(of: [...])`    | Combiner plusieurs filtres |
| `.not(.screenshots)` | Exclure un type            |

### Accès à la Caméra

```swift
struct CameraPicker: UIViewControllerRepresentable {
    @Environment(\.dismiss) var dismiss
    @Binding var image: UIImage?

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera          // Caméra (pas galerie)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: CameraPicker

        init(_ parent: CameraPicker) {
            self.parent = parent
        }

        func imagePickerController(
            _ picker: UIImagePickerController,
            didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]
        ) {
            if let image = info[.originalImage] as? UIImage {
                parent.image = image
            }
            parent.dismiss()
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.dismiss()
        }
    }
}

// Utilisation
struct ContentView: View {
    @State private var showCamera = false
    @State private var capturedImage: UIImage?

    var body: some View {
        Button("Prendre une photo") {
            showCamera = true
        }
        .fullScreenCover(isPresented: $showCamera) {
            CameraPicker(image: $capturedImage)
        }
    }
}
```

### Sauvegarder une image

```swift
func saveImageToDocuments(image: UIImage, name: String) {
    guard let data = image.jpegData(compressionQuality: 0.8) else {
        print("❌ Impossible de convertir l'image")
        return
    }

    let documentsPath = FileManager.default.urls(
        for: .documentDirectory,
        in: .userDomainMask
    )[0]

    let fileURL = documentsPath.appendingPathComponent("\(name).jpg")

    do {
        try data.write(to: fileURL)
        print("✅ Image sauvegardée: \(fileURL.path)")
    } catch {
        print("❌ Erreur: \(error.localizedDescription)")
    }
}
```

### Configuration Info.plist requise

```xml
<!-- Accès à la galerie photos -->
<key>NSPhotoLibraryUsageDescription</key>
<string>L'application a besoin d'accéder à vos photos</string>

<!-- Accès à la caméra -->
<key>NSCameraUsageDescription</key>
<string>L'application a besoin d'accéder à la caméra</string>

<!-- Ajout de photos à la galerie (optionnel) -->
<key>NSPhotoLibraryAddUsageDescription</key>
<string>L'application souhaite sauvegarder des photos dans votre galerie</string>
```

### Points clés

| Élément                         | Rôle                                   |
| ------------------------------- | -------------------------------------- |
| `PhotosPicker`                  | Sélecteur moderne iOS 16+ (SwiftUI)    |
| `PhotosPickerItem`              | Représente un élément sélectionné      |
| `loadTransferable`              | Charge le contenu de l'élément         |
| `UIImagePickerController`       | Sélecteur classique (caméra + galerie) |
| `.sourceType = .camera`         | Mode caméra                            |
| `jpegData(compressionQuality:)` | Convertir UIImage en Data JPEG         |

---

## 3. Gestion des PDF

### Concept

iOS fournit `PDFKit` pour afficher et manipuler des documents PDF. On peut :

- Ouvrir et afficher des PDF existants
- Créer des PDF programmatiquement
- Exporter et partager des PDF

### Afficher un PDF avec PDFKit

```swift
import SwiftUI
import PDFKit

struct PDFKitView: UIViewRepresentable {
    let document: PDFDocument

    func makeUIView(context: Context) -> PDFKit.PDFView {
        let pdfView = PDFKit.PDFView()
        pdfView.document = document
        pdfView.autoScales = true                    // Zoom automatique
        pdfView.displayMode = .singlePageContinuous // Mode d'affichage
        pdfView.displayDirection = .vertical         // Direction du scroll
        return pdfView
    }

    func updateUIView(_ uiView: PDFKit.PDFView, context: Context) {
        uiView.document = document
    }
}

// Utilisation
struct PDFViewer: View {
    let pdfDocument: PDFDocument?

    var body: some View {
        if let document = pdfDocument {
            PDFKitView(document: document)
        } else {
            Text("Aucun PDF chargé")
        }
    }
}
```

### Charger un PDF depuis les Fichiers

```swift
import UniformTypeIdentifiers

struct PDFDocumentPicker: UIViewControllerRepresentable {
    let onPDFPicked: (URL) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(
            forOpeningContentTypes: [.pdf]    // Filtre: PDF uniquement
        )
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onPDFPicked: onPDFPicked)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPDFPicked: (URL) -> Void

        init(onPDFPicked: @escaping (URL) -> Void) {
            self.onPDFPicked = onPDFPicked
        }

        func documentPicker(
            _ controller: UIDocumentPickerViewController,
            didPickDocumentsAt urls: [URL]
        ) {
            guard let url = urls.first else { return }
            onPDFPicked(url)
        }
    }
}

// Charger le PDF
func loadPDF(from url: URL) -> PDFDocument? {
    // Accéder au fichier sécurisé
    guard url.startAccessingSecurityScopedResource() else {
        print("❌ Impossible d'accéder au fichier")
        return nil
    }
    defer { url.stopAccessingSecurityScopedResource() }

    return PDFDocument(url: url)
}
```

### Créer un PDF programmatiquement

```swift
func createPDF(title: String, content: String) -> Data {
    // Métadonnées du PDF
    let pdfMetaData = [
        kCGPDFContextCreator: "Mon App iOS",
        kCGPDFContextAuthor: "Utilisateur",
        kCGPDFContextTitle: title
    ]

    let format = UIGraphicsPDFRendererFormat()
    format.documentInfo = pdfMetaData as [String: Any]

    // Dimensions de la page (US Letter)
    let pageWidth: CGFloat = 612
    let pageHeight: CGFloat = 792
    let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
    let margin: CGFloat = 50

    // Créer le renderer
    let renderer = UIGraphicsPDFRenderer(bounds: pageRect, format: format)

    // Générer le PDF
    let data = renderer.pdfData { context in
        context.beginPage()

        // Dessiner le titre
        let titleAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 24),
            .foregroundColor: UIColor.black
        ]
        let titleRect = CGRect(
            x: margin,
            y: margin,
            width: pageWidth - margin * 2,
            height: 50
        )
        title.draw(in: titleRect, withAttributes: titleAttributes)

        // Ligne de séparation
        context.cgContext.setStrokeColor(UIColor.gray.cgColor)
        context.cgContext.setLineWidth(1)
        context.cgContext.move(to: CGPoint(x: margin, y: margin + 60))
        context.cgContext.addLine(to: CGPoint(x: pageWidth - margin, y: margin + 60))
        context.cgContext.strokePath()

        // Dessiner le contenu
        let contentAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 14),
            .foregroundColor: UIColor.black
        ]
        let contentRect = CGRect(
            x: margin,
            y: margin + 80,
            width: pageWidth - margin * 2,
            height: pageHeight - margin * 2 - 80
        )
        content.draw(in: contentRect, withAttributes: contentAttributes)
    }

    return data
}

// Utilisation
let pdfData = createPDF(
    title: "Mon Document",
    content: "Contenu du document..."
)

// Créer un PDFDocument à partir des données
if let document = PDFDocument(data: pdfData) {
    print("✅ PDF créé avec \(document.pageCount) page(s)")
}
```

### Sauvegarder et exporter un PDF

```swift
func savePDFToFiles(data: Data, fileName: String) -> URL? {
    let tempURL = FileManager.default.temporaryDirectory
        .appendingPathComponent(fileName)

    do {
        try data.write(to: tempURL)
        return tempURL
    } catch {
        print("❌ Erreur: \(error.localizedDescription)")
        return nil
    }
}

// Utiliser DocumentExportPicker pour "Enregistrer dans Fichiers"
struct DocumentExportPicker: UIViewControllerRepresentable {
    let url: URL
    let onCompletion: (Bool) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(
            forExporting: [url],
            asCopy: true
        )
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onCompletion: onCompletion)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onCompletion: (Bool) -> Void

        init(onCompletion: @escaping (Bool) -> Void) {
            self.onCompletion = onCompletion
        }

        func documentPicker(
            _ controller: UIDocumentPickerViewController,
            didPickDocumentsAt urls: [URL]
        ) {
            onCompletion(true)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCompletion(false)
        }
    }
}
```

### Modes d'affichage PDFView

| Mode                    | Description                |
| ----------------------- | -------------------------- |
| `.singlePage`           | Une page à la fois         |
| `.singlePageContinuous` | Scroll vertical continu    |
| `.twoUp`                | Deux pages côte à côte     |
| `.twoUpContinuous`      | Deux pages, scroll continu |

### Fonctionnalités avancées PDFKit

```swift
// Obtenir le nombre de pages
let pageCount = document.pageCount

// Accéder à une page spécifique
let page = document.page(at: 0)

// Rechercher du texte
let selections = document.findString("texte recherché", withOptions: .caseInsensitive)

// Ajouter une annotation
let annotation = PDFAnnotation(
    bounds: CGRect(x: 100, y: 100, width: 200, height: 50),
    forType: .highlight,
    withProperties: nil
)
page?.addAnnotation(annotation)
```

### Points clés

| Élément                                | Rôle                             |
| -------------------------------------- | -------------------------------- |
| `PDFDocument`                          | Représente un document PDF       |
| `PDFKit.PDFView`                       | Vue native pour afficher un PDF  |
| `UIGraphicsPDFRenderer`                | Créer des PDF programmatiquement |
| `forOpeningContentTypes: [.pdf]`       | Filtre Document Picker PDF       |
| `forExporting:`                        | Mode export du Document Picker   |
| `startAccessingSecurityScopedResource` | Accès fichiers externes          |

---

## 4. Empêcher la Capture d'Écran

### Concept

iOS ne permet pas de **bloquer complètement** les captures d'écran, mais on peut :

1. **Détecter** les captures et enregistrements
2. **Masquer** le contenu sensible pendant la capture
3. **Réagir** après une capture (logger, alerter, etc.)

### Détecter les captures d'écran

```swift
import SwiftUI

class ScreenProtectionManager: ObservableObject {
    @Published var screenshotCount = 0
    @Published var lastEvent = ""

    private var screenshotObserver: NSObjectProtocol?

    func startMonitoring() {
        // Observer les captures d'écran
        screenshotObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.userDidTakeScreenshotNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.handleScreenshot()
        }
    }

    func stopMonitoring() {
        if let observer = screenshotObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    private func handleScreenshot() {
        screenshotCount += 1
        lastEvent = "📸 Capture détectée à \(Date())"
        print("⚠️ L'utilisateur a pris une capture d'écran!")

        // Actions possibles :
        // - Logger l'événement
        // - Envoyer une alerte au serveur
        // - Afficher un message à l'utilisateur
        // - Flouter temporairement l'écran
    }

    deinit {
        stopMonitoring()
    }
}
```

### Détecter l'enregistrement d'écran

```swift
class ScreenProtectionManager: ObservableObject {
    @Published var isBeingRecorded = false

    private var recordingObserver: NSObjectProtocol?

    func startMonitoring() {
        // Vérifier l'état initial
        isBeingRecorded = UIScreen.main.isCaptured

        // Observer les changements
        recordingObserver = NotificationCenter.default.addObserver(
            forName: UIScreen.capturedDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.handleRecordingChange()
        }
    }

    private func handleRecordingChange() {
        isBeingRecorded = UIScreen.main.isCaptured

        if isBeingRecorded {
            print("🎥 Enregistrement d'écran DÉMARRÉ")
            // Masquer le contenu sensible
        } else {
            print("✅ Enregistrement d'écran ARRÊTÉ")
            // Réafficher le contenu
        }
    }
}
```

### Masquer le contenu pendant l'enregistrement

```swift
struct ProtectedView: View {
    @StateObject private var protection = ScreenProtectionManager()

    var body: some View {
        ZStack {
            // Contenu sensible
            VStack {
                Text("Informations confidentielles")
                Text("Numéro de carte: 1234 5678 9012 3456")
            }

            // Overlay de protection si enregistrement
            if protection.isBeingRecorded {
                Color.black
                    .ignoresSafeArea()
                    .overlay(
                        VStack {
                            Image(systemName: "eye.slash.fill")
                                .font(.system(size: 60))
                                .foregroundColor(.white)
                            Text("Contenu masqué")
                                .foregroundColor(.white)
                                .font(.title)
                        }
                    )
            }
        }
        .onAppear {
            protection.startMonitoring()
        }
    }
}
```

### Utiliser SecureField pour masquer le contenu

```swift
// Le contenu de SecureField apparaît NOIR dans les screenshots
struct SecureContentView: View {
    @State private var secureText = ""

    var body: some View {
        ZStack {
            // Ce champ sera masqué dans les captures
            SecureField("", text: $secureText)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.clear)

            // Votre contenu par-dessus
            Text("Ce texte sera visible normalement")
        }
    }
}
```

### Technique avancée : Masquer via UITextField secure

```swift
class SecureView: UIView {
    private let secureTextField = UITextField()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSecureLayer()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSecureLayer()
    }

    private func setupSecureLayer() {
        secureTextField.isSecureTextEntry = true
        secureTextField.isUserInteractionEnabled = false
        addSubview(secureTextField)

        // Le layer du secureTextField masque le contenu
        layer.superlayer?.addSublayer(secureTextField.layer)
        secureTextField.layer.sublayers?.first?.addSublayer(layer)
    }
}
```

### Points clés

| Élément                             | Rôle                                  |
| ----------------------------------- | ------------------------------------- |
| `userDidTakeScreenshotNotification` | Notification après une capture        |
| `capturedDidChangeNotification`     | Notification si enregistrement change |
| `UIScreen.main.isCaptured`          | Vérifie si l'écran est enregistré     |
| `SecureField` / `isSecureTextEntry` | Masque le contenu dans les captures   |

### ⚠️ Limitations

| Ce qu'on peut faire                 | Ce qu'on ne peut pas faire   |
| ----------------------------------- | ---------------------------- |
| ✅ Détecter les captures            | ❌ Bloquer les captures      |
| ✅ Détecter l'enregistrement        | ❌ Empêcher l'enregistrement |
| ✅ Masquer pendant l'enregistrement | ❌ Empêcher les outils tiers |
| ✅ Logger / Alerter                 | ❌ Supprimer les captures    |

---

## 5. Build iOS

### Concept

Le processus de build iOS transforme le code source en une application installable. Il inclut la compilation, la signature et le packaging.

### Configurations de Build

| Configuration | Usage         | Optimisations                   |
| ------------- | ------------- | ------------------------------- |
| **Debug**     | Développement | ❌ Non optimisé, symboles debug |
| **Release**   | Production    | ✅ Optimisé, pas de symboles    |

### Vérifier la configuration actuelle

```swift
#if DEBUG
    print("🔧 Mode DEBUG")
    let isDebug = true
#else
    print("🚀 Mode RELEASE")
    let isDebug = false
#endif

#if targetEnvironment(simulator)
    print("📱 Simulateur")
#else
    print("📱 Appareil réel")
#endif
```

### Informations du Bundle

```swift
func getBuildInfo() {
    let bundle = Bundle.main

    // Nom de l'app
    let appName = bundle.object(forInfoDictionaryKey: "CFBundleName") as? String ?? "N/A"

    // Bundle ID
    let bundleId = bundle.bundleIdentifier ?? "N/A"

    // Version (ex: "1.2.0")
    let version = bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "N/A"

    // Build number (ex: "42")
    let build = bundle.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "N/A"

    print("App: \(appName)")
    print("Bundle ID: \(bundleId)")
    print("Version: \(version) (\(build))")
}
```

### Informations de l'appareil

```swift
func getDeviceInfo() {
    let device = UIDevice.current

    print("Nom: \(device.name)")
    print("Modèle: \(device.model)")
    print("iOS: \(device.systemVersion)")
    print("ID: \(device.identifierForVendor?.uuidString ?? "N/A")")
}
```

### Processus de Build

```
┌─────────────────────────────────────────────────────────────┐
│                    PROCESSUS DE BUILD                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   1. COMPILATION                                            │
│      Swift → LLVM IR → Code machine                         │
│                                                             │
│   2. LINKING                                                │
│      Lier les frameworks et bibliothèques                   │
│                                                             │
│   3. PACKAGING                                              │
│      Créer le bundle .app avec ressources                   │
│                                                             │
│   4. SIGNATURE                                              │
│      Signer avec certificat + profil provisioning           │
│                                                             │
│   5. ARCHIVE (pour distribution)                            │
│      Créer .xcarchive pour App Store / Ad Hoc               │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Étapes pour distribuer une app

#### 1. Créer les certificats (Apple Developer Portal)

| Certificat   | Usage                    |
| ------------ | ------------------------ |
| Development  | Tester sur vos appareils |
| Distribution | App Store / Ad Hoc       |

#### 2. Créer un profil de provisioning

| Type        | Usage                 | Limite                |
| ----------- | --------------------- | --------------------- |
| Development | Tests internes        | Vos appareils         |
| Ad Hoc      | Tests externes        | 100 appareils         |
| App Store   | Distribution publique | Illimité              |
| Enterprise  | Distribution interne  | Illimité (entreprise) |

#### 3. Configurer Xcode

```
Xcode → Target → Signing & Capabilities
├── Team: Votre équipe Apple Developer
├── Bundle Identifier: com.votrecompany.app
├── Signing Certificate: Automatique ou manuel
└── Provisioning Profile: Automatique ou manuel
```

#### 4. Archiver l'application

```
Xcode → Product → Archive
```

#### 5. Exporter / Distribuer

| Option            | Destination                          |
| ----------------- | ------------------------------------ |
| App Store Connect | TestFlight + App Store               |
| Ad Hoc            | Installation directe (100 appareils) |
| Enterprise        | Distribution interne                 |
| Development       | Appareils de dev                     |

### Commandes Terminal

#### Build depuis le terminal

```bash
# Build debug
xcodebuild -workspace MyApp.xcworkspace \
    -scheme MyApp \
    -configuration Debug \
    -destination 'platform=iOS Simulator,name=iPhone 15'

# Build release
xcodebuild -workspace MyApp.xcworkspace \
    -scheme MyApp \
    -configuration Release
```

#### Archiver

```bash
xcodebuild archive \
    -workspace MyApp.xcworkspace \
    -scheme MyApp \
    -archivePath build/MyApp.xcarchive
```

#### Exporter IPA

```bash
xcodebuild -exportArchive \
    -archivePath build/MyApp.xcarchive \
    -exportPath build/ \
    -exportOptionsPlist ExportOptions.plist
```

#### Fichier ExportOptions.plist

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>app-store</string>  <!-- ou "ad-hoc", "development" -->
    <key>teamID</key>
    <string>VOTRE_TEAM_ID</string>
    <key>uploadSymbols</key>
    <true/>
    <key>compileBitcode</key>
    <true/>
</dict>
</plist>
```

### Build Settings importants

| Setting                          | Description                     |
| -------------------------------- | ------------------------------- |
| `PRODUCT_BUNDLE_IDENTIFIER`      | ID unique de l'app              |
| `MARKETING_VERSION`              | Version affichée (1.0.0)        |
| `CURRENT_PROJECT_VERSION`        | Numéro de build (1, 2, 3...)    |
| `CODE_SIGN_IDENTITY`             | Certificat de signature         |
| `PROVISIONING_PROFILE_SPECIFIER` | Profil de provisioning          |
| `IPHONEOS_DEPLOYMENT_TARGET`     | Version iOS minimum             |
| `TARGETED_DEVICE_FAMILY`         | 1=iPhone, 2=iPad, 1,2=Universal |

### Différences Debug vs Release

| Aspect         | Debug          | Release      |
| -------------- | -------------- | ------------ |
| Optimisations  | ❌ Désactivées | ✅ Activées  |
| Symboles debug | ✅ Inclus      | ❌ Exclus    |
| Assertions     | ✅ Actives     | ❌ Ignorées  |
| Logs           | ✅ Visibles    | ❌ Supprimés |
| Taille         | Plus grosse    | Plus petite  |
| Performance    | Plus lente     | Plus rapide  |

### Points clés

| Élément              | Rôle                              |
| -------------------- | --------------------------------- |
| `Bundle.main`        | Accès aux infos de l'app          |
| `#if DEBUG`          | Code conditionnel selon la config |
| `.xcarchive`         | Archive pour distribution         |
| `.ipa`               | Package installable               |
| Certificat           | Identité du développeur           |
| Provisioning Profile | Autorisations de l'app            |

---

## 📊 Résumé

| Fonctionnalité    | Framework / Outil                | Complexité |
| ----------------- | -------------------------------- | ---------- |
| Gestion fichiers  | `FileManager`                    | ⭐⭐       |
| Import fichiers   | `UIDocumentPickerViewController` | ⭐⭐       |
| Export fichiers   | `UIActivityViewController`       | ⭐         |
| Photos & Galerie  | `PhotosPicker` / `PhotosUI`      | ⭐⭐       |
| Caméra            | `UIImagePickerController`        | ⭐⭐       |
| Affichage PDF     | `PDFKit`                         | ⭐         |
| Création PDF      | `UIGraphicsPDFRenderer`          | ⭐⭐⭐     |
| Détection capture | `NotificationCenter`             | ⭐         |
| Masquer contenu   | `SecureField` / UIKit            | ⭐⭐⭐     |
| Build / Archive   | Xcode / xcodebuild               | ⭐⭐       |

---

## 🔧 Fichiers de la Demo

| Fichier                    | Description               |
| -------------------------- | ------------------------- |
| `Demo3App.swift`           | Point d'entrée            |
| `ContentView.swift`        | Menu de navigation        |
| `FileManagementView.swift` | Demo fichiers             |
| `PhotoGalleryView.swift`   | Demo photos et galerie    |
| `PDFView.swift`            | Demo création/lecture PDF |
| `ScreenCaptureView.swift`  | Demo protection écran     |
| `BuildInfoView.swift`      | Infos de build            |

---

## ✅ Checklist de la Demo

### Fichiers

- [ ] Créer un fichier texte
- [ ] Lire un fichier
- [ ] Lister les fichiers
- [ ] Supprimer un fichier
- [ ] Importer un fichier (Document Picker)
- [ ] Partager un fichier (Share Sheet)
- [ ] Enregistrer dans Fichiers (Export Picker)

### Photos & Galerie

- [ ] Ouvrir la galerie avec PhotosPicker
- [ ] Sélectionner plusieurs photos
- [ ] Prendre une photo avec la caméra
- [ ] Sauvegarder une image dans Documents
- [ ] Partager une image

### PDF

- [ ] Ouvrir un PDF depuis Fichiers
- [ ] Afficher un PDF avec PDFKit
- [ ] Créer un PDF avec titre et contenu
- [ ] Exporter le PDF vers Fichiers
- [ ] Partager un PDF

### Protection écran

- [ ] Détecter une capture d'écran
- [ ] Détecter un enregistrement d'écran
- [ ] Masquer le contenu pendant l'enregistrement
- [ ] Compter les tentatives

### Build

- [ ] Afficher la version et le build number
- [ ] Détecter Debug vs Release
- [ ] Détecter Simulateur vs Appareil
- [ ] Afficher les infos de l'appareil

---

## 📚 Ressources

- [FileManager - Apple](https://developer.apple.com/documentation/foundation/filemanager)
- [UIDocumentPickerViewController - Apple](https://developer.apple.com/documentation/uikit/uidocumentpickerviewcontroller)
- [PhotosPicker - Apple](https://developer.apple.com/documentation/photokit/photospicker)
- [PhotosUI - Apple](https://developer.apple.com/documentation/photosui)
- [UIImagePickerController - Apple](https://developer.apple.com/documentation/uikit/uiimagepickercontroller)
- [PDFKit - Apple](https://developer.apple.com/documentation/pdfkit)
- [UIGraphicsPDFRenderer - Apple](https://developer.apple.com/documentation/uikit/uigraphicspdfrenderer)
- [App Distribution Guide - Apple](https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases)
- [Code Signing - Apple](https://developer.apple.com/support/code-signing/)
