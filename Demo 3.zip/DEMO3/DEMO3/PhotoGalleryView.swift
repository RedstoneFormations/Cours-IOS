import SwiftUI
import PhotosUI

struct PhotoGalleryView: View {
    @StateObject private var viewModel = PhotoGalleryViewModel()

    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 80))
                    .foregroundColor(.orange)

                Text("Photos & Galerie")
                    .font(.title2)
                    .bold()

                // Section Sélection Photo
                VStack(alignment: .leading, spacing: 15) {
                    Text("Sélectionner une Photo")
                        .font(.headline)

                    // PhotosPicker natif iOS 16+
                    PhotosPicker(
                        selection: $viewModel.selectedItem,
                        matching: .images,
                        photoLibrary: .shared()
                    ) {
                        Label("Ouvrir la Galerie", systemImage: "photo.stack")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .cornerRadius(10)
                    }

                    // Sélection multiple
                    PhotosPicker(
                        selection: $viewModel.selectedItems,
                        maxSelectionCount: 5,
                        matching: .images,
                        photoLibrary: .shared()
                    ) {
                        Label("Sélection Multiple (max 5)", systemImage: "photo.on.rectangle")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .cornerRadius(10)
                    }

                    // Caméra
                    Button(action: {
                        viewModel.showCamera = true
                    }) {
                        Label("Prendre une Photo", systemImage: "camera.fill")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.green)
                            .cornerRadius(10)
                    }
                }
                .padding()
                .background(Color.orange.opacity(0.1))
                .cornerRadius(15)

                // Affichage de l'image sélectionnée
                if let image = viewModel.selectedImage {
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Image Sélectionnée")
                            .font(.headline)

                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 300)
                            .cornerRadius(10)

                        HStack {
                            Button(action: {
                                viewModel.saveImageToDocuments()
                            }) {
                                Label("Sauvegarder", systemImage: "square.and.arrow.down")
                                    .font(.subheadline)
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 10)
                                    .background(Color.purple)
                                    .cornerRadius(8)
                            }

                            Button(action: {
                                viewModel.shareImage()
                            }) {
                                Label("Partager", systemImage: "square.and.arrow.up")
                                    .font(.subheadline)
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 10)
                                    .background(Color.blue)
                                    .cornerRadius(8)
                            }
                        }
                    }
                    .padding()
                    .background(Color.purple.opacity(0.1))
                    .cornerRadius(15)
                }

                // Affichage des images multiples
                if !viewModel.selectedImages.isEmpty {
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Images Sélectionnées (\(viewModel.selectedImages.count))")
                            .font(.headline)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 10) {
                                ForEach(viewModel.selectedImages.indices, id: \.self) { index in
                                    Image(uiImage: viewModel.selectedImages[index])
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 100, height: 100)
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                }
                            }
                        }
                    }
                    .padding()
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(15)
                }

                // Messages
                if !viewModel.statusMessage.isEmpty {
                    Text(viewModel.statusMessage)
                        .font(.caption)
                        .foregroundColor(viewModel.isError ? .red : .green)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(viewModel.isError ? Color.red.opacity(0.1) : Color.green.opacity(0.1))
                        .cornerRadius(8)
                }
            }
            .padding()
        }
        .navigationTitle("Photos")
        .onChange(of: viewModel.selectedItem) { _ in
            viewModel.loadSelectedImage()
        }
        .onChange(of: viewModel.selectedItems) { _ in
            viewModel.loadSelectedImages()
        }
        .fullScreenCover(isPresented: $viewModel.showCamera) {
            CameraPicker(image: $viewModel.cameraImage)
        }
        .onChange(of: viewModel.cameraImage) { newImage in
            if let image = newImage {
                viewModel.selectedImage = image
                viewModel.statusMessage = "📷 Photo capturée!"
                viewModel.isError = false
            }
        }
        .sheet(isPresented: $viewModel.showShareSheet) {
            if let image = viewModel.selectedImage {
                ShareSheet(items: [image])
            }
        }
    }
}

// MARK: - PhotoGalleryViewModel
class PhotoGalleryViewModel: ObservableObject {
    @Published var selectedItem: PhotosPickerItem?
    @Published var selectedItems: [PhotosPickerItem] = []
    @Published var selectedImage: UIImage?
    @Published var selectedImages: [UIImage] = []
    @Published var cameraImage: UIImage?
    @Published var showCamera = false
    @Published var showShareSheet = false
    @Published var statusMessage = ""
    @Published var isError = false

    private let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]

    func loadSelectedImage() {
        guard let item = selectedItem else { return }

        item.loadTransferable(type: Data.self) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    if let data = data, let image = UIImage(data: data) {
                        self?.selectedImage = image
                        self?.statusMessage = "✅ Image chargée"
                        self?.isError = false
                    }
                case .failure(let error):
                    self?.statusMessage = "❌ Erreur: \(error.localizedDescription)"
                    self?.isError = true
                }
            }
        }
    }

    func loadSelectedImages() {
        selectedImages = []

        for item in selectedItems {
            item.loadTransferable(type: Data.self) { [weak self] result in
                DispatchQueue.main.async {
                    if case .success(let data) = result,
                       let data = data,
                       let image = UIImage(data: data) {
                        self?.selectedImages.append(image)
                    }
                }
            }
        }

        statusMessage = "✅ \(selectedItems.count) image(s) sélectionnée(s)"
        isError = false
    }

    func saveImageToDocuments() {
        guard let image = selectedImage,
              let data = image.jpegData(compressionQuality: 0.8) else {
            statusMessage = "❌ Aucune image à sauvegarder"
            isError = true
            return
        }

        let fileName = "photo-\(Int(Date().timeIntervalSince1970)).jpg"
        let fileURL = documentsPath.appendingPathComponent(fileName)

        do {
            try data.write(to: fileURL)
            statusMessage = "✅ Image sauvegardée: \(fileName)"
            isError = false
        } catch {
            statusMessage = "❌ Erreur: \(error.localizedDescription)"
            isError = true
        }
    }

    func shareImage() {
        guard selectedImage != nil else {
            statusMessage = "❌ Aucune image à partager"
            isError = true
            return
        }
        showShareSheet = true
    }
}

// MARK: - CameraPicker
struct CameraPicker: UIViewControllerRepresentable {
    @Environment(\.dismiss) var dismiss
    @Binding var image: UIImage?

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: CameraPicker

        init(_ parent: CameraPicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.image = image
            }
            parent.dismiss()
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.dismiss()
        }
    }
}
