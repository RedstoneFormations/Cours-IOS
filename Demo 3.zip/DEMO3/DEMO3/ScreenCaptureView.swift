import SwiftUI

struct ScreenCaptureView: View {
    @StateObject private var screenProtection = ScreenProtectionManager()

    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                Image(systemName: screenProtection.isProtected ? "lock.shield.fill" : "lock.open.fill")
                    .font(.system(size: 80))
                    .foregroundColor(screenProtection.isProtected ? .green : .red)

                Text("Protection Capture d'Écran")
                    .font(.title2)
                    .bold()

                // État de la protection
                VStack(spacing: 15) {
                    StatusCard(
                        title: "État de Protection",
                        value: screenProtection.isProtected ? "Activée" : "Désactivée",
                        icon: screenProtection.isProtected ? "checkmark.shield.fill" : "xmark.shield.fill",
                        color: screenProtection.isProtected ? .green : .red
                    )

                    StatusCard(
                        title: "Captures Détectées",
                        value: "\(screenProtection.captureAttempts)",
                        icon: "camera.fill",
                        color: .orange
                    )

                    StatusCard(
                        title: "Enregistrements Détectés",
                        value: "\(screenProtection.recordingAttempts)",
                        icon: "record.circle.fill",
                        color: .purple
                    )
                }

                // Toggle protection
                Toggle(isOn: $screenProtection.isProtected) {
                    Label("Activer la Protection", systemImage: "shield.fill")
                        .font(.headline)
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .onChange(of: screenProtection.isProtected) { newValue in
                    screenProtection.toggleProtection(newValue)
                }

                // Zone sensible
                VStack(spacing: 15) {
                    Text("Zone Sensible")
                        .font(.headline)

                    ZStack {
                        RoundedRectangle(cornerRadius: 15)
                            .fill(Color.red.opacity(0.1))
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.red, lineWidth: 2)
                            )

                        VStack(spacing: 10) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .font(.system(size: 50))
                                .foregroundColor(.red)

                            Text("Informations Confidentielles")
                                .font(.title3)
                                .bold()

                            Text("Cette zone devrait être protégée contre les captures d'écran")
                                .font(.caption)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                        }
                        .padding()

                        if screenProtection.isProtected {
                            // Overlay de protection
                            SecureField("", text: .constant(""))
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .background(Color.clear)
                        }
                    }
                    .frame(height: 200)
                }
                .padding()
                .background(Color.gray.opacity(0.05))
                .cornerRadius(15)

                // Informations
                VStack(alignment: .leading, spacing: 10) {
                    Text("ℹ️ Comment ça fonctionne")
                        .font(.headline)

                    Text("• Détection des captures d'écran via NotificationCenter")
                        .font(.caption)
                    Text("• Détection des enregistrements d'écran")
                        .font(.caption)
                    Text("• Floutage automatique des zones sensibles")
                        .font(.caption)
                    Text("• Utilisation de SecureTextField pour masquer le contenu")
                        .font(.caption)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.blue.opacity(0.1))
                .cornerRadius(10)

                if !screenProtection.lastEvent.isEmpty {
                    Text(screenProtection.lastEvent)
                        .font(.caption)
                        .foregroundColor(.orange)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(8)
                }
            }
            .padding()
        }
        .navigationTitle("Protection Écran")
        .onAppear {
            screenProtection.startMonitoring()
        }
        .onDisappear {
            screenProtection.stopMonitoring()
        }
    }
}

// MARK: - ScreenProtectionManager
class ScreenProtectionManager: ObservableObject {
    @Published var isProtected = false
    @Published var captureAttempts = 0
    @Published var recordingAttempts = 0
    @Published var lastEvent = ""

    private var screenCaptureObserver: NSObjectProtocol?
    private var screenRecordingObserver: NSObjectProtocol?

    func startMonitoring() {
        // Observer pour captures d'écran
        screenCaptureObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.userDidTakeScreenshotNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.handleScreenshot()
        }

        // Observer pour enregistrement d'écran
        screenRecordingObserver = NotificationCenter.default.addObserver(
            forName: UIScreen.capturedDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.handleScreenRecording()
        }
    }

    func stopMonitoring() {
        if let observer = screenCaptureObserver {
            NotificationCenter.default.removeObserver(observer)
        }
        if let observer = screenRecordingObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }

    func toggleProtection(_ enabled: Bool) {
        isProtected = enabled
        lastEvent = enabled ? "🛡️ Protection activée" : "⚠️ Protection désactivée"

        if enabled {
            // Empêcher les captures d'écran via SecureTextField dans les zones sensibles
            makeWindowSecure()
        } else {
            makeWindowNormal()
        }
    }

    private func handleScreenshot() {
        captureAttempts += 1
        lastEvent = "📸 Capture d'écran détectée! (\(timestamp()))"

        if isProtected {
            // Actions possibles:
            // - Logger l'événement
            // - Flouter l'écran temporairement
            // - Notifier l'utilisateur
            // - Envoyer un rapport de sécurité
        }
    }

    private func handleScreenRecording() {
        if UIScreen.main.isCaptured {
            recordingAttempts += 1
            lastEvent = "🎥 Enregistrement d'écran détecté! (\(timestamp()))"

            if isProtected {
                // Actions possibles:
                // - Masquer le contenu sensible
                // - Afficher un écran de protection
                // - Bloquer certaines fonctionnalités
            }
        } else {
            lastEvent = "✅ Enregistrement d'écran arrêté (\(timestamp()))"
        }
    }

    private func makeWindowSecure() {
        // Cette méthode peut être utilisée pour des protections additionnelles
        // Note: La vraie protection se fait au niveau de UITextField avec isSecureTextEntry
        guard let window = UIApplication.shared.windows.first else { return }

        // Option 1: Ajouter un overlay de protection
        let protectionView = UIView(frame: window.bounds)
        protectionView.backgroundColor = .clear
        protectionView.tag = 999

        // Cette vue capturera les screenshots mais n'empêchera pas complètement
        // Pour une vraie protection, utiliser UITextField avec isSecureTextEntry
    }

    private func makeWindowNormal() {
        guard let window = UIApplication.shared.windows.first else { return }
        window.viewWithTag(999)?.removeFromSuperview()
    }

    private func timestamp() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: Date())
    }

    deinit {
        stopMonitoring()
    }
}

// MARK: - StatusCard
struct StatusCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color

    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
                .frame(width: 40)

            VStack(alignment: .leading) {
                Text(title)
                    .font(.caption)
                    .foregroundColor(.gray)
                Text(value)
                    .font(.headline)
                    .bold()
            }

            Spacer()
        }
        .padding()
        .background(color.opacity(0.1))
        .cornerRadius(10)
    }
}
