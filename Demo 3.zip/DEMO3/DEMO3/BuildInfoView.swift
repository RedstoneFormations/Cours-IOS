import SwiftUI

struct BuildInfoView: View {
    @StateObject private var buildInfo = BuildInfoManager()

    var body: some View {
        List {
            Section(header: Text("Informations Application")) {
                InfoRow(label: "Nom", value: buildInfo.appName)
                InfoRow(label: "Bundle ID", value: buildInfo.bundleIdentifier)
                InfoRow(label: "Version", value: buildInfo.appVersion)
                InfoRow(label: "Build", value: buildInfo.buildNumber)
            }

            Section(header: Text("Configuration")) {
                InfoRow(label: "Mode", value: buildInfo.buildConfiguration)
                InfoRow(label: "Environnement", value: buildInfo.isDebug ? "Debug" : "Release")
                InfoRow(label: "Simulateur", value: buildInfo.isSimulator ? "Oui" : "Non")
            }

            Section(header: Text("Système")) {
                InfoRow(label: "iOS Version", value: buildInfo.iosVersion)
                InfoRow(label: "Appareil", value: buildInfo.deviceModel)
                InfoRow(label: "Nom", value: buildInfo.deviceName)
                InfoRow(label: "Identifiant", value: buildInfo.deviceIdentifier)
            }

            Section(header: Text("Processus de Build iOS")) {
                VStack(alignment: .leading, spacing: 15) {
                    BuildStep(
                        number: "1",
                        title: "Configuration Xcode",
                        description: "Build Configurations: Debug, Release",
                        icon: "hammer.fill"
                    )

                    BuildStep(
                        number: "2",
                        title: "Signature",
                        description: "Certificat + Profil de provisioning",
                        icon: "signature"
                    )

                    BuildStep(
                        number: "3",
                        title: "Archive",
                        description: "Product → Archive",
                        icon: "archivebox.fill"
                    )

                    BuildStep(
                        number: "4",
                        title: "Export",
                        description: "App Store, Ad Hoc, Enterprise, Development",
                        icon: "arrow.up.doc.fill"
                    )

                    BuildStep(
                        number: "5",
                        title: "Distribution",
                        description: "TestFlight ou App Store Connect",
                        icon: "airplane.departure"
                    )
                }
                .padding(.vertical)
            }

            Section(header: Text("Commandes Utiles")) {
                CommandRow(
                    title: "Build depuis terminal",
                    command: "xcodebuild -workspace App.xcworkspace -scheme App -configuration Release"
                )

                CommandRow(
                    title: "Archive",
                    command: "xcodebuild archive -workspace App.xcworkspace -scheme App -archivePath build/App.xcarchive"
                )

                CommandRow(
                    title: "Export IPA",
                    command: "xcodebuild -exportArchive -archivePath build/App.xcarchive -exportPath build -exportOptionsPlist options.plist"
                )
            }

            Section(header: Text("Configurations Importantes")) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Info.plist")
                        .font(.headline)
                    Text("• Bundle Identifier")
                    Text("• Version & Build Number")
                    Text("• Permissions (Camera, Location, etc.)")

                    Divider().padding(.vertical)

                    Text("Build Settings")
                        .font(.headline)
                    Text("• Code Signing Identity")
                    Text("• Provisioning Profile")
                    Text("• Deployment Target")
                    Text("• Architectures")
                }
                .font(.caption)
                .padding(.vertical, 5)
            }
        }
        .navigationTitle("Build iOS")
    }
}

// MARK: - BuildInfoManager
class BuildInfoManager: ObservableObject {
    @Published var appName = ""
    @Published var bundleIdentifier = ""
    @Published var appVersion = ""
    @Published var buildNumber = ""
    @Published var buildConfiguration = ""
    @Published var isDebug = false
    @Published var isSimulator = false
    @Published var iosVersion = ""
    @Published var deviceModel = ""
    @Published var deviceName = ""
    @Published var deviceIdentifier = ""

    init() {
        loadAppInfo()
        loadSystemInfo()
    }

    private func loadAppInfo() {
        let bundle = Bundle.main

        appName = bundle.object(forInfoDictionaryKey: "CFBundleName") as? String ?? "N/A"
        bundleIdentifier = bundle.bundleIdentifier ?? "N/A"
        appVersion = bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "N/A"
        buildNumber = bundle.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "N/A"

        #if DEBUG
        isDebug = true
        buildConfiguration = "Debug"
        #else
        isDebug = false
        buildConfiguration = "Release"
        #endif

        #if targetEnvironment(simulator)
        isSimulator = true
        #else
        isSimulator = false
        #endif
    }

    private func loadSystemInfo() {
        let device = UIDevice.current

        iosVersion = device.systemVersion
        deviceName = device.name
        deviceModel = device.model
        deviceIdentifier = device.identifierForVendor?.uuidString ?? "N/A"
    }
}

// MARK: - BuildStep
struct BuildStep: View {
    let number: String
    let title: String
    let description: String
    let icon: String

    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            ZStack {
                Circle()
                    .fill(Color.blue)
                    .frame(width: 30, height: 30)
                Text(number)
                    .font(.caption)
                    .bold()
                    .foregroundColor(.white)
            }

            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Image(systemName: icon)
                        .foregroundColor(.blue)
                    Text(title)
                        .font(.headline)
                }
                Text(description)
                    .font(.caption)
                    .foregroundColor(.gray)
            }

            Spacer()
        }
    }
}

// MARK: - InfoRow
struct InfoRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .foregroundColor(.gray)
            Spacer()
            Text(value)
                .font(.subheadline)
                .bold()
        }
    }
}

// MARK: - CommandRow
struct CommandRow: View {
    let title: String
    let command: String
    @State private var showCopied = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.subheadline)
                .bold()

            HStack {
                Text(command)
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(.gray)
                    .lineLimit(2)

                Spacer()

                Button(action: {
                    UIPasteboard.general.string = command
                    showCopied = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        showCopied = false
                    }
                }) {
                    Image(systemName: showCopied ? "checkmark" : "doc.on.doc")
                        .foregroundColor(.blue)
                }
            }
            .padding(8)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(5)
        }
        .padding(.vertical, 5)
    }
}
