import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            List {
                Section(header: Text("DEMO 3: Fichiers & Sécurité").font(.title3).bold()) {

                    NavigationLink(destination: FileManagementView()) {
                        Label("Upload & Download Fichiers", systemImage: "doc.fill")
                            .foregroundColor(.blue)
                    }

                    NavigationLink(destination: PhotoGalleryView()) {
                        Label("Photos & Galerie", systemImage: "photo.on.rectangle.angled")
                            .foregroundColor(.orange)
                    }

                    NavigationLink(destination: PDFDemoView()) {
                        Label("Gestion des PDF", systemImage: "doc.richtext.fill")
                            .foregroundColor(.red)
                    }

                    NavigationLink(destination: ScreenCaptureView()) {
                        Label("Protection Capture d'Écran", systemImage: "lock.shield.fill")
                            .foregroundColor(.purple)
                    }

                    NavigationLink(destination: BuildInfoView()) {
                        Label("Informations Build iOS", systemImage: "info.circle.fill")
                            .foregroundColor(.green)
                    }
                }
            }
            .navigationTitle("Fichiers & Sécurité")
        }
    }
}
