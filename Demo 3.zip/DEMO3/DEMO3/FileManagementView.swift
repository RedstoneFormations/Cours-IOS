import SwiftUI
import UniformTypeIdentifiers

struct FileManagementView: View {
    @StateObject private var fileManager = FileManagerViewModel()

    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                Image(systemName: "doc.text.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.blue)

                Text("Gestion des Fichiers")
                    .font(.title2)
                    .bold()

                // Section Upload
                VStack(alignment: .leading, spacing: 15) {
                    Text("Upload de Fichiers")
                        .font(.headline)

                    Button(action: {
                        fileManager.showDocumentPicker = true
                    }) {
                        Label("Sélectionner un fichier", systemImage: "arrow.up.doc.fill")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .cornerRadius(10)
                    }

                    Button(action: {
                        fileManager.createAndSaveTextFile()
                    }) {
                        Label("Créer un fichier texte", systemImage: "doc.badge.plus")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.green)
                            .cornerRadius(10)
                    }
                }
                .padding()
                .background(Color.blue.opacity(0.1))
                .cornerRadius(15)

                // Section Download
                VStack(alignment: .leading, spacing: 15) {
                    Text("Download de Fichiers")
                        .font(.headline)

                    Button(action: {
                        fileManager.downloadSampleFile()
                    }) {
                        Label("Télécharger fichier test", systemImage: "arrow.down.doc.fill")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.purple)
                            .cornerRadius(10)
                    }

                    if fileManager.isDownloading {
                        ProgressView("Téléchargement...", value: fileManager.downloadProgress)
                            .padding()
                    }
                }
                .padding()
                .background(Color.purple.opacity(0.1))
                .cornerRadius(15)

                // Section Fichiers sauvegardés
                VStack(alignment: .leading, spacing: 15) {
                    HStack {
                        Text("Fichiers Locaux")
                            .font(.headline)
                        Spacer()
                        Button(action: fileManager.loadSavedFiles) {
                            Image(systemName: "arrow.clockwise")
                                .foregroundColor(.blue)
                        }
                    }

                    if fileManager.savedFiles.isEmpty {
                        Text("Aucun fichier")
                            .foregroundColor(.gray)
                            .italic()
                    } else {
                        ForEach(fileManager.savedFiles, id: \.self) { file in
                            FileRow(fileName: file) {
                                fileManager.shareFile(file)
                            } onDelete: {
                                fileManager.deleteFile(file)
                            }
                        }
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(15)

                // Messages
                if !fileManager.statusMessage.isEmpty {
                    Text(fileManager.statusMessage)
                        .font(.caption)
                        .foregroundColor(fileManager.isError ? .red : .green)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(fileManager.isError ? Color.red.opacity(0.1) : Color.green.opacity(0.1))
                        .cornerRadius(8)
                }
            }
            .padding()
        }
        .navigationTitle("Fichiers")
        .sheet(isPresented: $fileManager.showDocumentPicker) {
            DocumentPicker(onFilePicked: fileManager.handlePickedFile)
        }
        .sheet(item: $fileManager.fileToShare) { file in
            ShareSheet(items: [file.url])
        }
        .sheet(isPresented: $fileManager.showExportPicker) {
            if let url = fileManager.fileToExport {
                DocumentExportPicker(url: url) { success in
                    fileManager.handleExportCompleted(success: success)
                }
            }
        }
        .onAppear {
            fileManager.loadSavedFiles()
        }
    }
}

// MARK: - FileManagerViewModel
class FileManagerViewModel: ObservableObject {
    @Published var savedFiles: [String] = []
    @Published var statusMessage = ""
    @Published var isError = false
    @Published var showDocumentPicker = false
    @Published var showExportPicker = false
    @Published var fileToExport: URL?
    @Published var fileToShare: ShareableFile?
    @Published var isDownloading = false
    @Published var downloadProgress: Double = 0.0

    private let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]

    struct ShareableFile: Identifiable {
        let id = UUID()
        let url: URL
    }

    func loadSavedFiles() {
        do {
            let files = try FileManager.default.contentsOfDirectory(atPath: documentsPath.path)
            savedFiles = files.sorted()
            statusMessage = "✅ \(files.count) fichier(s) trouvé(s)"
            isError = false
        } catch {
            statusMessage = "❌ Erreur de lecture: \(error.localizedDescription)"
            isError = true
        }
    }

    func handlePickedFile(_ url: URL) {
        let fileName = url.lastPathComponent
        let destinationURL = documentsPath.appendingPathComponent(fileName)

        do {
            // Copier le fichier
            if FileManager.default.fileExists(atPath: destinationURL.path) {
                try FileManager.default.removeItem(at: destinationURL)
            }
            try FileManager.default.copyItem(at: url, to: destinationURL)

            statusMessage = "✅ Fichier importé: \(fileName)"
            isError = false
            loadSavedFiles()
        } catch {
            statusMessage = "❌ Erreur d'import: \(error.localizedDescription)"
            isError = true
        }
    }

    func createAndSaveTextFile() {
        let fileName = "test-\(Date().timeIntervalSince1970).txt"
        let fileURL = documentsPath.appendingPathComponent(fileName)
        let content = """
        Fichier de test créé le \(Date())

        Ceci est un exemple de contenu de fichier.
        Vous pouvez créer n'importe quel type de fichier.
        """

        do {
            try content.write(to: fileURL, atomically: true, encoding: .utf8)
            statusMessage = "✅ Fichier créé: \(fileName)"
            isError = false
            loadSavedFiles()
        } catch {
            statusMessage = "❌ Erreur de création: \(error.localizedDescription)"
            isError = true
        }
    }

    func downloadSampleFile() {
        // Simuler un téléchargement
        isDownloading = true
        downloadProgress = 0.0

        let timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] timer in
            guard let self = self else {
                timer.invalidate()
                return
            }

            self.downloadProgress += 0.1

            if self.downloadProgress >= 1.0 {
                timer.invalidate()
                self.finishDownload()
            }
        }

        RunLoop.current.add(timer, forMode: .common)
    }

    private func finishDownload() {
        let fileName = "downloaded-\(Int(Date().timeIntervalSince1970)).json"
        // Sauvegarder dans le dossier temporaire d'abord
        let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)
        let content = """
        {
            "downloaded": true,
            "timestamp": "\(Date())",
            "message": "Fichier téléchargé avec succès"
        }
        """

        do {
            try content.write(to: tempURL, atomically: true, encoding: .utf8)
            isDownloading = false
            // Ouvrir le sélecteur "Enregistrer dans Fichiers"
            fileToExport = tempURL
            showExportPicker = true
            statusMessage = "📁 Choisissez où enregistrer le fichier"
            isError = false
        } catch {
            isDownloading = false
            statusMessage = "❌ Erreur de sauvegarde: \(error.localizedDescription)"
            isError = true
        }
    }

    func handleExportCompleted(success: Bool) {
        if success {
            statusMessage = "✅ Fichier enregistré avec succès!"
            isError = false
        } else {
            statusMessage = "⚠️ Export annulé"
            isError = false
        }
        // Nettoyer le fichier temporaire
        if let tempURL = fileToExport {
            try? FileManager.default.removeItem(at: tempURL)
        }
        fileToExport = nil
    }

    func shareFile(_ fileName: String) {
        let fileURL = documentsPath.appendingPathComponent(fileName)
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            statusMessage = "❌ Fichier introuvable"
            isError = true
            return
        }
        fileToShare = ShareableFile(url: fileURL)
    }

    func deleteFile(_ fileName: String) {
        let fileURL = documentsPath.appendingPathComponent(fileName)

        do {
            try FileManager.default.removeItem(at: fileURL)
            statusMessage = "✅ Fichier supprimé: \(fileName)"
            isError = false
            loadSavedFiles()
        } catch {
            statusMessage = "❌ Erreur de suppression: \(error.localizedDescription)"
            isError = true
        }
    }
}

// MARK: - DocumentPicker
struct DocumentPicker: UIViewControllerRepresentable {
    let onFilePicked: (URL) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onFilePicked: onFilePicked)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onFilePicked: (URL) -> Void

        init(onFilePicked: @escaping (URL) -> Void) {
            self.onFilePicked = onFilePicked
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            onFilePicked(url)
        }
    }
}

// MARK: - ShareSheet
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// MARK: - DocumentExportPicker (Save to Files)
struct DocumentExportPicker: UIViewControllerRepresentable {
    let url: URL
    let onCompletion: (Bool) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // Mode export: permet à l'utilisateur de choisir où enregistrer
        let picker = UIDocumentPickerViewController(forExporting: [url], asCopy: true)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onCompletion: onCompletion)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onCompletion: (Bool) -> Void

        init(onCompletion: @escaping (Bool) -> Void) {
            self.onCompletion = onCompletion
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            // L'utilisateur a choisi un emplacement
            onCompletion(true)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            // L'utilisateur a annulé
            onCompletion(false)
        }
    }
}

// MARK: - FileRow
struct FileRow: View {
    let fileName: String
    let onShare: () -> Void
    let onDelete: () -> Void

    var body: some View {
        HStack {
            Image(systemName: iconForFile(fileName))
                .foregroundColor(.blue)

            Text(fileName)
                .font(.subheadline)

            Spacer()

            Button(action: onShare) {
                Image(systemName: "square.and.arrow.up")
                    .foregroundColor(.blue)
            }
            .buttonStyle(BorderlessButtonStyle())

            Button(action: onDelete) {
                Image(systemName: "trash")
                    .foregroundColor(.red)
            }
            .buttonStyle(BorderlessButtonStyle())
        }
        .padding(.vertical, 5)
    }

    private func iconForFile(_ name: String) -> String {
        let ext = (name as NSString).pathExtension.lowercased()
        switch ext {
        case "txt": return "doc.text"
        case "json": return "doc.badge.gearshape"
        case "pdf": return "doc.richtext"
        case "jpg", "jpeg", "png": return "photo"
        default: return "doc"
        }
    }
}
