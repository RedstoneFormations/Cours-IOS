import SwiftUI

@main
struct Demo3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
