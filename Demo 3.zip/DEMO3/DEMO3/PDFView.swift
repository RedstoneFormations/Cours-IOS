import SwiftUI
import PDFKit
import UniformTypeIdentifiers

struct PDFDemoView: View {
    @StateObject private var viewModel = PDFViewModel()

    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                Image(systemName: "doc.richtext.fill")
                    .font(.system(size: 80))
                    .foregroundColor(.red)

                Text("Gestion des PDF")
                    .font(.title2)
                    .bold()

                // Section Sélection PDF
                VStack(alignment: .leading, spacing: 15) {
                    Text("Ouvrir un PDF")
                        .font(.headline)

                    Button(action: {
                        viewModel.showDocumentPicker = true
                    }) {
                        Label("Sélectionner un PDF", systemImage: "doc.badge.plus")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.red)
                            .cornerRadius(10)
                    }
                }
                .padding()
                .background(Color.red.opacity(0.1))
                .cornerRadius(15)

                // Section Création PDF
                VStack(alignment: .leading, spacing: 15) {
                    Text("Créer un PDF")
                        .font(.headline)

                    TextField("Titre du document", text: $viewModel.pdfTitle)
                        .textFieldStyle(RoundedBorderTextFieldStyle())

                    TextEditor(text: $viewModel.pdfContent)
                        .frame(height: 100)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                        )

                    Button(action: {
                        viewModel.createPDF()
                    }) {
                        Label("Générer PDF", systemImage: "doc.badge.gearshape")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.green)
                            .cornerRadius(10)
                    }
                }
                .padding()
                .background(Color.green.opacity(0.1))
                .cornerRadius(15)

                // Affichage PDF
                if let pdfDocument = viewModel.pdfDocument {
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Text("Aperçu PDF")
                                .font(.headline)
                            Spacer()
                            Text("\(pdfDocument.pageCount) page(s)")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }

                        PDFKitView(document: pdfDocument)
                            .frame(height: 400)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                            )

                        HStack {
                            Button(action: {
                                viewModel.sharePDF()
                            }) {
                                Label("Partager", systemImage: "square.and.arrow.up")
                                    .font(.subheadline)
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 10)
                                    .background(Color.blue)
                                    .cornerRadius(8)
                            }

                            Button(action: {
                                viewModel.savePDFToFiles()
                            }) {
                                Label("Enregistrer dans Fichiers", systemImage: "folder.badge.plus")
                                    .font(.subheadline)
                                    .foregroundColor(.white)
                                    .padding(.horizontal, 20)
                                    .padding(.vertical, 10)
                                    .background(Color.purple)
                                    .cornerRadius(8)
                            }
                        }
                    }
                    .padding()
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(15)
                }

                // Messages
                if !viewModel.statusMessage.isEmpty {
                    Text(viewModel.statusMessage)
                        .font(.caption)
                        .foregroundColor(viewModel.isError ? .red : .green)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(viewModel.isError ? Color.red.opacity(0.1) : Color.green.opacity(0.1))
                        .cornerRadius(8)
                }
            }
            .padding()
        }
        .navigationTitle("PDF")
        .sheet(isPresented: $viewModel.showDocumentPicker) {
            PDFDocumentPicker(onPDFPicked: viewModel.handlePickedPDF)
        }
        .sheet(isPresented: $viewModel.showExportPicker) {
            if let url = viewModel.pdfURLToExport {
                DocumentExportPicker(url: url) { success in
                    viewModel.handleExportCompleted(success: success)
                }
            }
        }
        .sheet(isPresented: $viewModel.showShareSheet) {
            if let url = viewModel.currentPDFURL {
                ShareSheet(items: [url])
            }
        }
    }
}

// MARK: - PDFViewModel
class PDFViewModel: ObservableObject {
    @Published var pdfDocument: PDFDocument?
    @Published var currentPDFURL: URL?
    @Published var pdfURLToExport: URL?
    @Published var pdfTitle = "Mon Document"
    @Published var pdfContent = "Ceci est le contenu de mon document PDF.\n\nVous pouvez écrire plusieurs paragraphes ici."
    @Published var showDocumentPicker = false
    @Published var showExportPicker = false
    @Published var showShareSheet = false
    @Published var statusMessage = ""
    @Published var isError = false

    private let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]

    func handlePickedPDF(_ url: URL) {
        guard url.startAccessingSecurityScopedResource() else {
            statusMessage = "❌ Impossible d'accéder au fichier"
            isError = true
            return
        }

        defer { url.stopAccessingSecurityScopedResource() }

        // Copier le fichier localement
        let fileName = url.lastPathComponent
        let localURL = documentsPath.appendingPathComponent(fileName)

        do {
            if FileManager.default.fileExists(atPath: localURL.path) {
                try FileManager.default.removeItem(at: localURL)
            }
            try FileManager.default.copyItem(at: url, to: localURL)

            if let document = PDFDocument(url: localURL) {
                pdfDocument = document
                currentPDFURL = localURL
                statusMessage = "✅ PDF chargé: \(fileName)"
                isError = false
            } else {
                statusMessage = "❌ Impossible de lire le PDF"
                isError = true
            }
        } catch {
            statusMessage = "❌ Erreur: \(error.localizedDescription)"
            isError = true
        }
    }

    func createPDF() {
        let pdfMetaData = [
            kCGPDFContextCreator: "Demo3 iOS App",
            kCGPDFContextAuthor: "Formation iOS",
            kCGPDFContextTitle: pdfTitle
        ]

        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = pdfMetaData as [String: Any]

        let pageWidth: CGFloat = 612 // US Letter
        let pageHeight: CGFloat = 792
        let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
        let margin: CGFloat = 50

        let renderer = UIGraphicsPDFRenderer(bounds: pageRect, format: format)

        let data = renderer.pdfData { context in
            context.beginPage()

            // Titre
            let titleAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.boldSystemFont(ofSize: 24),
                .foregroundColor: UIColor.black
            ]
            let titleRect = CGRect(x: margin, y: margin, width: pageWidth - margin * 2, height: 50)
            pdfTitle.draw(in: titleRect, withAttributes: titleAttributes)

            // Ligne de séparation
            context.cgContext.setStrokeColor(UIColor.gray.cgColor)
            context.cgContext.setLineWidth(1)
            context.cgContext.move(to: CGPoint(x: margin, y: margin + 60))
            context.cgContext.addLine(to: CGPoint(x: pageWidth - margin, y: margin + 60))
            context.cgContext.strokePath()

            // Date
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .long
            dateFormatter.timeStyle = .short
            let dateString = "Créé le: \(dateFormatter.string(from: Date()))"
            let dateAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.italicSystemFont(ofSize: 12),
                .foregroundColor: UIColor.gray
            ]
            let dateRect = CGRect(x: margin, y: margin + 70, width: pageWidth - margin * 2, height: 20)
            dateString.draw(in: dateRect, withAttributes: dateAttributes)

            // Contenu
            let contentAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 14),
                .foregroundColor: UIColor.black
            ]
            let contentRect = CGRect(x: margin, y: margin + 110, width: pageWidth - margin * 2, height: pageHeight - margin * 2 - 110)
            pdfContent.draw(in: contentRect, withAttributes: contentAttributes)

            // Footer
            let footerText = "Généré par Demo3 - Formation iOS"
            let footerAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 10),
                .foregroundColor: UIColor.lightGray
            ]
            let footerRect = CGRect(x: margin, y: pageHeight - margin, width: pageWidth - margin * 2, height: 20)
            footerText.draw(in: footerRect, withAttributes: footerAttributes)
        }

        // Sauvegarder le PDF
        let fileName = "document-\(Int(Date().timeIntervalSince1970)).pdf"
        let fileURL = FileManager.default.temporaryDirectory.appendingPathComponent(fileName)

        do {
            try data.write(to: fileURL)
            pdfDocument = PDFDocument(data: data)
            currentPDFURL = fileURL
            statusMessage = "✅ PDF créé avec succès!"
            isError = false
        } catch {
            statusMessage = "❌ Erreur: \(error.localizedDescription)"
            isError = true
        }
    }

    func sharePDF() {
        guard currentPDFURL != nil else {
            statusMessage = "❌ Aucun PDF à partager"
            isError = true
            return
        }
        showShareSheet = true
    }

    func savePDFToFiles() {
        guard let url = currentPDFURL else {
            statusMessage = "❌ Aucun PDF à enregistrer"
            isError = true
            return
        }
        pdfURLToExport = url
        showExportPicker = true
    }

    func handleExportCompleted(success: Bool) {
        if success {
            statusMessage = "✅ PDF enregistré avec succès!"
            isError = false
        } else {
            statusMessage = "⚠️ Export annulé"
            isError = false
        }
    }
}

// MARK: - PDFKitView
struct PDFKitView: UIViewRepresentable {
    let document: PDFDocument

    func makeUIView(context: Context) -> PDFKit.PDFView {
        let pdfView = PDFKit.PDFView()
        pdfView.document = document
        pdfView.autoScales = true
        pdfView.displayMode = .singlePageContinuous
        pdfView.displayDirection = .vertical
        return pdfView
    }

    func updateUIView(_ uiView: PDFKit.PDFView, context: Context) {
        uiView.document = document
    }
}

// MARK: - PDFDocumentPicker
struct PDFDocumentPicker: UIViewControllerRepresentable {
    let onPDFPicked: (URL) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.pdf])
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onPDFPicked: onPDFPicked)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPDFPicked: (URL) -> Void

        init(onPDFPicked: @escaping (URL) -> Void) {
            self.onPDFPicked = onPDFPicked
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else { return }
            onPDFPicked(url)
        }
    }
}
