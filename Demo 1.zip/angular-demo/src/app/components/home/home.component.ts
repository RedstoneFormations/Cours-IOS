import { Component, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { SwiftBridgeService } from "../../services/swift-bridge.service";

@Component({
	selector: "app-home",
	standalone: true,
	imports: [CommonModule, RouterModule],
	template: `
		<div class="card">
			<h2><span class="emoji">🏠</span> Bienvenue dans la Demo</h2>
			<p>
				Cette application Angular est conçue pour être intégrée dans une
				application SwiftUI via WKWebView.
			</p>

			<div
				class="status-badge"
				[class.connected]="isConnected"
				[class.disconnected]="!isConnected"
			>
				<span>{{ isConnected ? "🟢" : "🔴" }}</span>
				{{ isConnected ? "Connecté à Swift" : "Mode Standalone" }}
			</div>
		</div>

		<div class="card">
			<h2><span class="emoji">📚</span> Sections de la Demo</h2>

			<div class="button-group">
				<a routerLink="/swift-to-angular" class="btn btn-primary">
					📲 Swift → Angular
				</a>
				<a routerLink="/angular-to-swift" class="btn btn-success">
					📤 Angular → Swift
				</a>
				<a routerLink="/route-guard" class="btn btn-warning">
					🛡️ Guard Routes
				</a>
			</div>
		</div>

		<div class="card">
			<h2><span class="emoji">⚙️</span> Comment ça marche</h2>

			<div class="section-title">1. Embed dans SwiftUI</div>
			<p>L'app Angular est chargée dans un WKWebView intégré dans SwiftUI.</p>

			<div class="section-title" style="margin-top: 1rem;">
				2. Communication
			</div>
			<p>Swift et Angular communiquent via:</p>
			<ul style="margin-left: 1.5rem; margin-top: 0.5rem;">
				<li><code>window.webkit.messageHandlers</code> (Angular → Swift)</li>
				<li><code>evaluateJavaScript</code> (Swift → Angular)</li>
			</ul>

			<div class="section-title" style="margin-top: 1rem;">
				3. Navigation Guard
			</div>
			<p>
				WKNavigationDelegate intercepte les navigations pour bloquer certaines
				URLs.
			</p>
		</div>

		<div class="card">
			<h2><span class="emoji">💻</span> Code Swift</h2>

			<div class="code-block">
				<span class="comment">// Recevoir des messages d'Angular</span><br />
				<span class="keyword">func</span> userContentController(<br />
				&nbsp;&nbsp;_ userContentController: WKUserContentController,<br />
				&nbsp;&nbsp;didReceive message: WKScriptMessage<br />
				) {{ "{" }}<br />
				&nbsp;&nbsp;<span class="keyword">if</span>
				<span class="keyword">let</span> body = message.body
				<span class="keyword">as?</span> String {{ "{" }}<br />
				&nbsp;&nbsp;&nbsp;&nbsp;print(<span class="string"
					>"Message Angular: \\(body)"</span
				>)<br />
				&nbsp;&nbsp;{{ "}" }}<br />
				{{ "}" }}
			</div>

			<div class="code-block" style="margin-top: 1rem;">
				<span class="comment">// Envoyer un message à Angular</span><br />
				webView.evaluateJavaScript(<br />
				&nbsp;&nbsp;<span class="string"
					>"window.receiveFromSwift('Hello!')"</span
				><br />
				)
			</div>
		</div>
	`,
})
export class HomeComponent implements OnInit {
	isConnected = false;

	constructor(private swiftBridge: SwiftBridgeService) {}

	ngOnInit(): void {
		this.swiftBridge.connected$.subscribe((connected) => {
			this.isConnected = connected;
		});
	}
}
