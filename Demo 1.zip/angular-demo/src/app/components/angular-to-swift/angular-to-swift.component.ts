import { Component, OnInit, OnDestroy } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import {
	SwiftBridgeService,
	Message,
} from "../../services/swift-bridge.service";
import { Subscription } from "rxjs";

@Component({
	selector: "app-angular-to-swift",
	standalone: true,
	imports: [CommonModule, FormsModule],
	template: `
		<div class="card">
			<h2><span class="emoji">📤</span> Angular → Swift</h2>
			<p>
				Cette section démontre comment Angular peut envoyer des événements à
				Swift.
			</p>

			<div
				class="status-badge"
				[class.connected]="isConnected"
				[class.disconnected]="!isConnected"
			>
				<span>{{ isConnected ? "🟢" : "🔴" }}</span>
				{{ isConnected ? "Connecté à Swift" : "Mode Standalone" }}
			</div>
		</div>

		<div class="card">
			<h2><span class="emoji">✉️</span> Envoyer un Message</h2>

			<div class="input-group">
				<input
					type="text"
					[(ngModel)]="messageToSend"
					placeholder="Tapez votre message..."
					(keyup.enter)="sendMessage()"
				/>
				<button class="btn btn-primary" (click)="sendMessage()">
					📨 Envoyer
				</button>
			</div>

			<div class="button-group">
				<button
					class="btn btn-success"
					(click)="sendPredefinedMessage('user_logged_in')"
				>
					👤 Login Event
				</button>
				<button
					class="btn btn-warning"
					(click)="sendPredefinedMessage('button_clicked')"
				>
					👆 Click Event
				</button>
				<button
					class="btn btn-secondary"
					(click)="sendPredefinedMessage('page_loaded')"
				>
					📄 Page Load
				</button>
			</div>
		</div>

		<div class="card">
			<h2><span class="emoji">📋</span> Messages Envoyés</h2>

			<div
				class="messages-list"
				*ngIf="sentMessages.length > 0; else noMessages"
			>
				<div class="message-item" *ngFor="let msg of sentMessages">
					<div>
						<strong>{{ msg.content }}</strong>
					</div>
					<div class="timestamp">{{ msg.timestamp | date : "HH:mm:ss" }}</div>
				</div>
			</div>

			<ng-template #noMessages>
				<p style="color: #999; font-style: italic; margin-top: 1rem;">
					Aucun message envoyé.
				</p>
			</ng-template>

			<button
				class="btn btn-secondary"
				(click)="clearMessages()"
				style="margin-top: 1rem;"
			>
				🗑️ Effacer l'historique
			</button>
		</div>

		<div class="card">
			<h2><span class="emoji">💻</span> Comment implémenter</h2>

			<div class="section-title">Côté Angular (envoyer)</div>
			<div class="code-block">
				<span class="comment">// Utiliser webkit.messageHandlers</span><br />
				<span class="keyword">if</span>
				(window.webkit?.messageHandlers?.swiftHandler) {{ "{" }}<br />
				&nbsp;&nbsp;window.webkit.messageHandlers.swiftHandler<br />
				&nbsp;&nbsp;&nbsp;&nbsp;.postMessage(<span class="string"
					>'Mon message'</span
				>);<br />
				{{ "}" }}
			</div>

			<div class="section-title" style="margin-top: 1rem;">
				Côté Swift (recevoir)
			</div>
			<div class="code-block">
				<span class="comment">// Implémenter WKScriptMessageHandler</span><br />
				<span class="keyword">class</span> Coordinator: WKScriptMessageHandler
				{{ "{" }}<br />
				&nbsp;&nbsp;<span class="keyword">func</span>
				userContentController(<br />
				&nbsp;&nbsp;&nbsp;&nbsp;_ controller: WKUserContentController,<br />
				&nbsp;&nbsp;&nbsp;&nbsp;didReceive message: WKScriptMessage<br />
				&nbsp;&nbsp;) {{ "{" }}<br />
				&nbsp;&nbsp;&nbsp;&nbsp;<span class="keyword">if let</span> body =
				message.body <span class="keyword">as?</span> String {{ "{" }}<br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;print(<span class="string"
					>"Reçu: \\(body)"</span
				>)<br />
				&nbsp;&nbsp;&nbsp;&nbsp;{{ "}" }}<br />
				&nbsp;&nbsp;{{ "}" }}<br />
				{{ "}" }}
			</div>
		</div>

		<div class="card">
			<h2><span class="emoji">📋</span> Cas d'usage</h2>
			<ul class="link-list">
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">🔔</span> Demander à Swift d'envoyer une
					notification
				</li>
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">📞</span> Déclencher un appel téléphonique
				</li>
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">📷</span> Ouvrir la caméra native
				</li>
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">💾</span> Sauvegarder des données dans Keychain
				</li>
			</ul>
		</div>
	`,
})
export class AngularToSwiftComponent implements OnInit, OnDestroy {
	messageToSend = "";
	sentMessages: Message[] = [];
	isConnected = false;
	private subscription?: Subscription;

	constructor(private swiftBridge: SwiftBridgeService) {}

	ngOnInit(): void {
		this.subscription = this.swiftBridge.messages$.subscribe((messages) => {
			this.sentMessages = messages.filter((m) => m.source === "angular");
		});

		this.swiftBridge.connected$.subscribe((connected) => {
			this.isConnected = connected;
		});
	}

	ngOnDestroy(): void {
		this.subscription?.unsubscribe();
	}

	sendMessage(): void {
		if (this.messageToSend.trim()) {
			this.swiftBridge.sendToSwift(this.messageToSend.trim());
			this.messageToSend = "";
		}
	}

	sendPredefinedMessage(type: string): void {
		const messages: Record<string, string> = {
			user_logged_in: JSON.stringify({
				event: "login",
				user: "demo@example.com",
				timestamp: Date.now(),
			}),
			button_clicked: JSON.stringify({
				event: "click",
				element: "submit-button",
				timestamp: Date.now(),
			}),
			page_loaded: JSON.stringify({
				event: "pageLoad",
				route: "/angular-to-swift",
				timestamp: Date.now(),
			}),
		};

		this.swiftBridge.sendToSwift(messages[type] || type);
	}

	clearMessages(): void {
		this.swiftBridge.clearMessages();
	}
}
