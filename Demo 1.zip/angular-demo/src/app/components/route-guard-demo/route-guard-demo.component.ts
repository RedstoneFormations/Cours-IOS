import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SwiftBridgeService } from "../../services/swift-bridge.service";

interface RouteExample {
	url: string;
	label: string;
	icon: string;
	allowed: boolean;
	description: string;
}

@Component({
	selector: "app-route-guard-demo",
	standalone: true,
	imports: [CommonModule],
	template: `
		<div class="card">
			<h2><span class="emoji">🛡️</span> Guard des Routes</h2>
			<p>
				Cette section démontre comment Swift peut intercepter et bloquer
				certaines navigations.
			</p>
			<p style="margin-top: 0.5rem; color: #666;">
				Les URLs non autorisées s'ouvriront dans Safari au lieu de la WebView.
			</p>
		</div>

		<div class="card">
			<h2><span class="emoji">✅</span> URLs Autorisées</h2>
			<p>Ces URLs s'afficheront dans la WebView:</p>

			<ul class="link-list">
				<li *ngFor="let route of allowedRoutes">
					<a [href]="route.url" (click)="handleNavigation($event, route)">
						<span class="emoji">{{ route.icon }}</span>
						<div>
							<strong>{{ route.label }}</strong>
							<div style="font-size: 0.75rem; color: #666;">
								{{ route.description }}
							</div>
						</div>
					</a>
				</li>
			</ul>
		</div>

		<div class="card">
			<h2><span class="emoji">🚫</span> URLs Bloquées</h2>
			<p>Ces URLs s'ouvriront dans Safari (bloquées par le guard Swift):</p>

			<ul class="link-list">
				<li *ngFor="let route of blockedRoutes">
					<a
						[href]="route.url"
						class="blocked"
						(click)="handleNavigation($event, route)"
					>
						<span class="emoji">{{ route.icon }}</span>
						<div>
							<strong>{{ route.label }}</strong>
							<div style="font-size: 0.75rem;">{{ route.description }}</div>
						</div>
					</a>
				</li>
			</ul>
		</div>

		<div class="card">
			<h2><span class="emoji">💻</span> Comment implémenter</h2>

			<div class="section-title">Swift - WKNavigationDelegate</div>
			<div class="code-block">
				<span class="comment">// Liste des domaines autorisés</span><br />
				<span class="keyword">let</span> allowedDomains = [<br />
				&nbsp;&nbsp;<span class="string">"angular.io"</span>,<br />
				&nbsp;&nbsp;<span class="string">"localhost"</span><br />
				]<br /><br />

				<span class="keyword">func</span> webView(<br />
				&nbsp;&nbsp;_ webView: WKWebView,<br />
				&nbsp;&nbsp;decidePolicyFor action: WKNavigationAction,<br />
				&nbsp;&nbsp;decisionHandler: (WKNavigationActionPolicy) -> Void<br />
				) {{ "{" }}<br />
				&nbsp;&nbsp;<span class="keyword">guard let</span> url =
				action.request.url,<br />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="keyword">let</span>
				host = url.host <span class="keyword">else</span> {{ "{" }}<br />
				&nbsp;&nbsp;&nbsp;&nbsp;decisionHandler(.cancel)<br />
				&nbsp;&nbsp;&nbsp;&nbsp;<span class="keyword">return</span><br />
				&nbsp;&nbsp;{{ "}" }}<br /><br />

				&nbsp;&nbsp;<span class="comment">// Vérifier si autorisé</span><br />
				&nbsp;&nbsp;<span class="keyword">let</span> isAllowed =
				allowedDomains<br />
				&nbsp;&nbsp;&nbsp;&nbsp;.contains {{ "{" }} host.contains($0) {{ "}"
				}}<br /><br />

				&nbsp;&nbsp;<span class="keyword">if</span> isAllowed {{ "{" }}<br />
				&nbsp;&nbsp;&nbsp;&nbsp;decisionHandler(.allow)<br />
				&nbsp;&nbsp;{{ "}" }} <span class="keyword">else</span> {{ "{" }}<br />
				&nbsp;&nbsp;&nbsp;&nbsp;<span class="comment"
					>// Ouvrir dans Safari</span
				><br />
				&nbsp;&nbsp;&nbsp;&nbsp;UIApplication.shared.open(url)<br />
				&nbsp;&nbsp;&nbsp;&nbsp;decisionHandler(.cancel)<br />
				&nbsp;&nbsp;{{ "}" }}<br />
				{{ "}" }}
			</div>
		</div>

		<div class="card">
			<h2><span class="emoji">📋</span> Cas d'usage</h2>
			<ul class="link-list">
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">🔒</span> Empêcher l'accès à des sites de phishing
				</li>
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">🌐</span> Ouvrir les liens externes dans Safari
				</li>
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">📊</span> Logger les tentatives de navigation
				</li>
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">🎯</span> Rediriger vers des pages internes
				</li>
			</ul>
		</div>

		<div class="card" *ngIf="lastNavigation">
			<h2><span class="emoji">📝</span> Dernière Navigation</h2>
			<div class="message-item" [class.from-swift]="lastNavigation.allowed">
				<div>
					<strong>{{
						lastNavigation.allowed ? "✅ Autorisée" : "🚫 Bloquée"
					}}</strong>
				</div>
				<div>{{ lastNavigation.url }}</div>
				<div class="timestamp">{{ lastNavigation.description }}</div>
			</div>
		</div>
	`,
})
export class RouteGuardDemoComponent {
	allowedRoutes: RouteExample[] = [
		{
			url: "https://angular.io",
			label: "Angular.io",
			icon: "🅰️",
			allowed: true,
			description: "Documentation Angular officielle",
		},
		{
			url: "https://angular.io/guide/router",
			label: "Angular Router Guide",
			icon: "🔀",
			allowed: true,
			description: "Guide du routeur Angular",
		},
		{
			url: "http://localhost:4200",
			label: "Localhost",
			icon: "🏠",
			allowed: true,
			description: "Serveur de développement local",
		},
	];

	blockedRoutes: RouteExample[] = [
		{
			url: "https://google.com",
			label: "Google",
			icon: "🔍",
			allowed: false,
			description: "S'ouvrira dans Safari",
		},
		{
			url: "https://github.com",
			label: "GitHub",
			icon: "🐙",
			allowed: false,
			description: "S'ouvrira dans Safari",
		},
		{
			url: "https://twitter.com",
			label: "Twitter/X",
			icon: "🐦",
			allowed: false,
			description: "S'ouvrira dans Safari",
		},
		{
			url: "https://facebook.com",
			label: "Facebook",
			icon: "📘",
			allowed: false,
			description: "S'ouvrira dans Safari",
		},
	];

	lastNavigation: RouteExample | null = null;

	constructor(private swiftBridge: SwiftBridgeService) {}

	handleNavigation(event: Event, route: RouteExample): void {
		this.lastNavigation = route;

		// Notifier Swift de la tentative de navigation
		this.swiftBridge.sendToSwift(
			JSON.stringify({
				event: "navigation_attempt",
				url: route.url,
				allowed: route.allowed,
				timestamp: Date.now(),
			})
		);

		// Si c'est un lien bloqué, on laisse le comportement par défaut
		// (Swift interceptera et ouvrira dans Safari)
		// Si c'est autorisé, on laisse aussi le comportement par défaut
	}
}
