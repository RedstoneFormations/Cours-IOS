import { Component, OnInit, OnDestroy } from "@angular/core";
import { CommonModule } from "@angular/common";
import {
	SwiftBridgeService,
	Message,
} from "../../services/swift-bridge.service";
import { Subscription } from "rxjs";

@Component({
	selector: "app-swift-to-angular",
	standalone: true,
	imports: [CommonModule],
	template: `
		<div class="card">
			<h2><span class="emoji">📲</span> Swift → Angular</h2>
			<p>
				Cette section démontre comment Swift peut envoyer des événements à
				Angular.
			</p>

			<div
				class="status-badge"
				[class.connected]="isConnected"
				[class.disconnected]="!isConnected"
			>
				<span>{{ isConnected ? "🟢" : "🔴" }}</span>
				{{
					isConnected
						? "En attente de messages Swift..."
						: "Mode Standalone (simulation)"
				}}
			</div>
		</div>

		<div class="card">
			<h2><span class="emoji">📥</span> Messages Reçus de Swift</h2>

			<div
				class="messages-list"
				*ngIf="messagesFromSwift.length > 0; else noMessages"
			>
				<div
					class="message-item from-swift"
					*ngFor="let msg of messagesFromSwift"
				>
					<div>
						<strong>{{ msg.content }}</strong>
					</div>
					<div class="timestamp">{{ msg.timestamp | date : "HH:mm:ss" }}</div>
				</div>
			</div>

			<ng-template #noMessages>
				<p style="color: #999; font-style: italic; margin-top: 1rem;">
					Aucun message reçu. Depuis Swift, utilisez le bouton "Envoyer" ou
					tapez un message.
				</p>
			</ng-template>

			<div class="button-group" style="margin-top: 1rem;">
				<button class="btn btn-secondary" (click)="simulateSwiftMessage()">
					🔄 Simuler message Swift
				</button>
				<button class="btn btn-secondary" (click)="clearMessages()">
					🗑️ Effacer
				</button>
			</div>
		</div>

		<div class="card">
			<h2><span class="emoji">💻</span> Comment implémenter</h2>

			<div class="section-title">Côté Swift (envoyer)</div>
			<div class="code-block">
				<span class="comment">// Appeler une fonction JavaScript</span><br />
				webView.evaluateJavaScript(<br />
				&nbsp;&nbsp;<span class="string"
					>"window.receiveFromSwift('Mon message')"</span
				><br />
				) {{ "{" }} result, error <span class="keyword">in</span><br />
				&nbsp;&nbsp;<span class="keyword">if let</span> error = error {{ "{"
				}}<br />
				&nbsp;&nbsp;&nbsp;&nbsp;print(<span class="string"
					>"Erreur: \\(error)"</span
				>)<br />
				&nbsp;&nbsp;{{ "}" }}<br />
				{{ "}" }}
			</div>

			<div class="section-title" style="margin-top: 1rem;">
				Côté Angular (recevoir)
			</div>
			<div class="code-block">
				<span class="comment">// Exposer une fonction globale</span><br />
				window.receiveFromSwift = (message: string) => {{ "{" }}<br />
				&nbsp;&nbsp;console.log(<span class="string">'Reçu de Swift:'</span>,
				message);<br />
				&nbsp;&nbsp;<span class="comment">// Traiter le message...</span><br />
				{{ "}" }};
			</div>
		</div>

		<div class="card">
			<h2><span class="emoji">📋</span> Cas d'usage</h2>
			<ul class="link-list">
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">🔔</span> Notifier Angular d'un événement système
					iOS
				</li>
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">📍</span> Envoyer la position GPS à Angular
				</li>
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">🔐</span> Transmettre un token d'authentification
				</li>
				<li
					style="padding: 0.75rem 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 0.5rem;"
				>
					<span class="emoji">📱</span> Informer sur l'état de la batterie
				</li>
			</ul>
		</div>
	`,
})
export class SwiftToAngularComponent implements OnInit, OnDestroy {
	messagesFromSwift: Message[] = [];
	isConnected = false;
	private subscription?: Subscription;

	constructor(private swiftBridge: SwiftBridgeService) {}

	ngOnInit(): void {
		// S'abonner aux messages
		this.subscription = this.swiftBridge.messages$.subscribe((messages) => {
			this.messagesFromSwift = messages.filter((m) => m.source === "swift");
		});

		// Vérifier la connexion
		this.swiftBridge.connected$.subscribe((connected) => {
			this.isConnected = connected;
		});
	}

	ngOnDestroy(): void {
		this.subscription?.unsubscribe();
	}

	simulateSwiftMessage(): void {
		// Simuler un message comme si il venait de Swift
		const messages = [
			"Hello depuis Swift! 👋",
			"Batterie: 85%",
			"Position GPS: 48.8566° N, 2.3522° E",
			"Token: abc123xyz",
			"App en premier plan",
		];
		const randomMessage = messages[Math.floor(Math.random() * messages.length)];

		// Appeler la fonction comme Swift le ferait
		if (window.receiveFromSwift) {
			window.receiveFromSwift(randomMessage);
		}
	}

	clearMessages(): void {
		this.swiftBridge.clearMessages();
	}
}
