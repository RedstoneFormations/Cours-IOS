import { Component } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { SwiftBridgeService } from "./services/swift-bridge.service";

@Component({
	selector: "app-root",
	standalone: true,
	imports: [CommonModule, RouterModule],
	template: `
		<nav class="navbar">
			<div class="navbar-content">
				<h1>🔗 Angular + Swift</h1>
				<div class="nav-links">
					<a
						routerLink="/"
						routerLinkActive="active"
						[routerLinkActiveOptions]="{ exact: true }"
						>Accueil</a
					>
					<a routerLink="/swift-to-angular" routerLinkActive="active"
						>Swift → Angular</a
					>
					<a routerLink="/angular-to-swift" routerLinkActive="active"
						>Angular → Swift</a
					>
					<a routerLink="/route-guard" routerLinkActive="active">Routes</a>
				</div>
			</div>
		</nav>

		<main class="container">
			<router-outlet></router-outlet>
		</main>
	`,
})
export class AppComponent {
	constructor(private swiftBridge: SwiftBridgeService) {
		// Initialiser le bridge au démarrage
		this.swiftBridge.initialize();
	}
}
