import { Injectable, NgZone } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";

// Déclaration pour TypeScript
declare global {
	interface Window {
		webkit?: {
			messageHandlers?: {
				swiftHandler?: {
					postMessage: (message: string) => void;
				};
			};
		};
		sendToSwift?: (message: string) => void;
		receiveFromSwift?: (message: string) => void;
	}
}

export interface Message {
	content: string;
	timestamp: Date;
	source: "angular" | "swift";
}

@Injectable({
	providedIn: "root",
})
export class SwiftBridgeService {
	private messagesSubject = new BehaviorSubject<Message[]>([]);
	private connectedSubject = new BehaviorSubject<boolean>(false);

	messages$: Observable<Message[]> = this.messagesSubject.asObservable();
	connected$: Observable<boolean> = this.connectedSubject.asObservable();

	constructor(private ngZone: NgZone) {}

	/**
	 * Initialise le bridge de communication avec Swift
	 * Cette fonction expose `window.receiveFromSwift` pour que Swift puisse envoyer des messages
	 */
	initialize(): void {
		// Exposer la fonction pour recevoir des messages de Swift
		// IMPORTANT: NgZone.run() force Angular à détecter les changements
		window.receiveFromSwift = (message: string) => {
			this.ngZone.run(() => {
				this.handleMessageFromSwift(message);
			});
		};

		// Écouter les postMessage (autre méthode de communication)
		window.addEventListener("message", (event) => {
			if (event.data?.source === "swift") {
				this.ngZone.run(() => {
					this.handleMessageFromSwift(event.data.data);
				});
			}
		});

		// Vérifier si on est dans une WKWebView
		this.checkConnection();

		console.log("🔗 SwiftBridgeService initialisé");
	}

	/**
	 * Vérifie si l'app est exécutée dans une WKWebView iOS
	 */
	private checkConnection(): void {
		const isInWebView = !!(
			window.webkit?.messageHandlers?.swiftHandler || window.sendToSwift
		);
		this.connectedSubject.next(isInWebView);
	}

	/**
	 * Traite un message reçu de Swift
	 */
	private handleMessageFromSwift(content: string): void {
		const message: Message = {
			content,
			timestamp: new Date(),
			source: "swift",
		};

		const currentMessages = this.messagesSubject.value;
		this.messagesSubject.next([...currentMessages, message]);

		console.log("📥 Message reçu de Swift:", content);
	}

	/**
	 * Envoie un message à Swift
	 * Utilise window.webkit.messageHandlers.swiftHandler.postMessage
	 */
	sendToSwift(content: string): boolean {
		// Méthode 1: Via webkit messageHandlers (préféré)
		if (window.webkit?.messageHandlers?.swiftHandler) {
			window.webkit.messageHandlers.swiftHandler.postMessage(content);
			this.logSentMessage(content);
			return true;
		}

		// Méthode 2: Via fonction globale sendToSwift
		if (window.sendToSwift) {
			window.sendToSwift(content);
			this.logSentMessage(content);
			return true;
		}

		// Méthode 3: Via postMessage (fallback)
		window.postMessage({ source: "angular", message: content }, "*");
		this.logSentMessage(content);

		console.warn(
			"⚠️ Pas de connexion Swift détectée, message envoyé en mode simulation"
		);
		return false;
	}

	/**
	 * Log le message envoyé dans l'historique
	 */
	private logSentMessage(content: string): void {
		const message: Message = {
			content,
			timestamp: new Date(),
			source: "angular",
		};

		const currentMessages = this.messagesSubject.value;
		this.messagesSubject.next([...currentMessages, message]);

		console.log("📤 Message envoyé à Swift:", content);
	}

	/**
	 * Vide l'historique des messages
	 */
	clearMessages(): void {
		this.messagesSubject.next([]);
	}

	/**
	 * Vérifie si on est connecté à Swift
	 */
	isConnected(): boolean {
		return this.connectedSubject.value;
	}
}
