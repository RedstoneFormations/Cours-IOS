import { Routes } from "@angular/router";
import { HomeComponent } from "./components/home/home.component";
import { SwiftToAngularComponent } from "./components/swift-to-angular/swift-to-angular.component";
import { AngularToSwiftComponent } from "./components/angular-to-swift/angular-to-swift.component";
import { RouteGuardDemoComponent } from "./components/route-guard-demo/route-guard-demo.component";

export const routes: Routes = [
	{ path: "", component: HomeComponent },
	{ path: "swift-to-angular", component: SwiftToAngularComponent },
	{ path: "angular-to-swift", component: AngularToSwiftComponent },
	{ path: "route-guard", component: RouteGuardDemoComponent },
	{ path: "**", redirectTo: "" },
];
