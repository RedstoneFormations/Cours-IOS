# Angular + SwiftUI Demo

Application Angular conçue pour être intégrée dans une app SwiftUI via WKWebView.

## Installation

```bash
cd angular-demo
npm install
```

## Développement

```bash
npm start
# L'app sera disponible sur http://localhost:4200
```

## Build pour Production

```bash
npm run build
# Les fichiers seront dans dist/angular-swift-demo
```

## Structure

```
src/
├── app/
│   ├── components/
│   │   ├── home/                    # Page d'accueil
│   │   ├── swift-to-angular/        # Demo: Swift → Angular
│   │   ├── angular-to-swift/        # Demo: Angular → Swift
│   │   └── route-guard-demo/        # Demo: Guard des routes
│   ├── services/
│   │   └── swift-bridge.service.ts  # Service de communication
│   ├── app.component.ts
│   └── app.routes.ts
└── styles.css
```

## Communication avec Swift

### Angular → Swift

```typescript
// Utiliser le service
constructor(private swiftBridge: SwiftBridgeService) {}

// Envoyer un message
this.swiftBridge.sendToSwift('Mon message');
```

### Swift → Angular

```swift
// Depuis Swift
webView.evaluateJavaScript("window.receiveFromSwift('Message')")
```

```typescript
// Angular reçoit automatiquement via le service
this.swiftBridge.messages$.subscribe((messages) => {
	// Traiter les messages
});
```

## Intégration dans Xcode

1. Build l'app Angular: `npm run build`
2. Copier le contenu de `dist/angular-swift-demo/browser/` dans le projet Xcode
3. Charger `index.html` depuis les ressources du bundle

Ou utiliser un serveur local pendant le développement.
