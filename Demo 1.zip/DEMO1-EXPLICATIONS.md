# Demo 1 : Intégration Angular + SwiftUI

## 📋 Sommaire

1. [Afficher Angular dans SwiftUI](#1-afficher-angular-dans-swiftui)
2. [Guard des Routes](#2-guard-des-routes)
3. [Événements Angular → Swift](#3-événements-angular--swift)
4. [Événements Swift → Angular](#4-événements-swift--angular)

---

## 1. Afficher Angular dans SwiftUI

### Concept

SwiftUI ne peut pas afficher directement du contenu web. On utilise **WKWebView** (UIKit) encapsulé dans un `UIViewRepresentable`.

### Implémentation

```swift
struct WebViewRepresentable: UIViewRepresentable {

    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView(frame: .zero, configuration: config)

        // Charger l'URL
        if let url = URL(string: "http://localhost:4200") {
            webView.load(URLRequest(url: url))
        }

        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        // Mise à jour si nécessaire
    }
}
```

### Points clés

| Élément               | Rôle                                          |
| --------------------- | --------------------------------------------- |
| `UIViewRepresentable` | Protocole pour intégrer UIKit dans SwiftUI    |
| `makeUIView`          | Crée et configure la vue UIKit                |
| `updateUIView`        | Met à jour la vue quand l'état SwiftUI change |
| `WKWebView`           | Composant WebKit pour afficher du contenu web |

### Configuration Info.plist

Pour charger des URLs HTTP en développement :

```xml
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsArbitraryLoads</key>
    <true/>
</dict>
```

---

## 2. Guard des Routes

### Concept

Le **guard des routes** permet de contrôler la navigation dans la WebView :

- ✅ URLs autorisées → affichées dans la WebView
- 🚫 URLs bloquées → ouvertes dans Safari

### Implémentation Swift

```swift
class Coordinator: NSObject, WKNavigationDelegate {

    // Liste des domaines autorisés
    let allowedDomains = ["angular.io", "localhost", "127.0.0.1"]

    // Intercepter chaque navigation
    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        guard let url = navigationAction.request.url,
              let host = url.host else {
            decisionHandler(.cancel)
            return
        }

        // Vérifier si le domaine est autorisé
        let isAllowed = allowedDomains.contains { host.contains($0) }

        if isAllowed {
            decisionHandler(.allow)  // ✅ Autoriser
        } else {
            UIApplication.shared.open(url)  // 🌐 Ouvrir dans Safari
            decisionHandler(.cancel)  // 🚫 Bloquer dans la WebView
        }
    }
}
```

### Points clés

| Élément                       | Rôle                                     |
| ----------------------------- | ---------------------------------------- |
| `WKNavigationDelegate`        | Protocole pour intercepter la navigation |
| `decidePolicyFor`             | Méthode appelée AVANT chaque navigation  |
| `decisionHandler(.allow)`     | Autoriser la navigation                  |
| `decisionHandler(.cancel)`    | Bloquer la navigation                    |
| `UIApplication.shared.open()` | Ouvrir une URL dans Safari               |

### Cas d'usage

- 🔒 Bloquer les sites de phishing
- 🌐 Ouvrir les liens externes dans Safari
- 📊 Logger les tentatives de navigation
- 🎯 Rediriger vers des pages internes

---

## 3. Événements Angular → Swift

### Concept

Angular envoie des messages à Swift via **webkit.messageHandlers**.

### Côté Angular (TypeScript)

```typescript
// Envoyer un message à Swift
function sendToSwift(message: string): void {
	if (window.webkit?.messageHandlers?.swiftHandler) {
		window.webkit.messageHandlers.swiftHandler.postMessage(message);
	}
}

// Exemple d'utilisation
sendToSwift('{"event": "login", "user": "demo@example.com"}');
```

### Côté Swift

```swift
class Coordinator: NSObject, WKScriptMessageHandler {

    // Recevoir les messages de JavaScript
    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage
    ) {
        // Vérifier le nom du handler
        if message.name == "swiftHandler" {
            // Extraire le contenu du message
            if let body = message.body as? String {
                print("📥 Message d'Angular: \(body)")
                // Traiter le message...
            }
        }
    }
}
```

### Configuration du Handler

```swift
func makeUIView(context: Context) -> WKWebView {
    let config = WKWebViewConfiguration()
    let userContentController = WKUserContentController()

    // Enregistrer le handler "swiftHandler"
    userContentController.add(context.coordinator, name: "swiftHandler")

    config.userContentController = userContentController

    return WKWebView(frame: .zero, configuration: config)
}
```

### Points clés

| Élément                                  | Rôle                                    |
| ---------------------------------------- | --------------------------------------- |
| `WKScriptMessageHandler`                 | Protocole pour recevoir les messages JS |
| `userContentController.add()`            | Enregistrer un handler avec un nom      |
| `webkit.messageHandlers.X.postMessage()` | Envoyer depuis JS vers Swift            |
| `message.body`                           | Contenu du message reçu                 |

### Cas d'usage

- 📞 Déclencher un appel téléphonique
- 🔔 Demander l'envoi d'une notification
- 📷 Ouvrir la caméra native
- 💾 Sauvegarder dans Keychain
- 📍 Demander la position GPS

---

## 4. Événements Swift → Angular

### Concept

Swift envoie des messages à Angular via **evaluateJavaScript**.

### Côté Swift

```swift
// Envoyer un message à Angular
func sendMessageToAngular(_ message: String, webView: WKWebView) {
    // Échapper les caractères spéciaux
    let escapedMessage = message
        .replacingOccurrences(of: "\\", with: "\\\\")
        .replacingOccurrences(of: "'", with: "\\'")

    // Appeler la fonction JavaScript
    let script = "window.receiveFromSwift('\(escapedMessage)')"

    webView.evaluateJavaScript(script) { result, error in
        if let error = error {
            print("❌ Erreur: \(error.localizedDescription)")
        } else {
            print("✅ Message envoyé")
        }
    }
}
```

### Côté Angular (TypeScript)

```typescript
import { Injectable, NgZone } from "@angular/core";

@Injectable({ providedIn: "root" })
export class SwiftBridgeService {
	constructor(private ngZone: NgZone) {}

	initialize(): void {
		// Exposer la fonction globale
		window.receiveFromSwift = (message: string) => {
			// ⚠️ IMPORTANT: NgZone pour mettre à jour l'UI
			this.ngZone.run(() => {
				this.handleMessage(message);
			});
		};
	}

	private handleMessage(message: string): void {
		console.log("📥 Message de Swift:", message);
		// Traiter le message...
	}
}
```

### Points clés

| Élément                   | Rôle                                            |
| ------------------------- | ----------------------------------------------- |
| `evaluateJavaScript()`    | Exécuter du code JS dans la WebView             |
| `window.receiveFromSwift` | Fonction globale exposée par Angular            |
| `NgZone.run()`            | **OBLIGATOIRE** pour mettre à jour l'UI Angular |

### ⚠️ Piège courant : NgZone

Quand Swift appelle `evaluateJavaScript`, le code s'exécute **en dehors de la zone Angular**. Sans `NgZone.run()`, l'UI ne se met pas à jour !

```typescript
// ❌ MAUVAIS - L'UI ne se met pas à jour
window.receiveFromSwift = (message) => {
	this.messages.push(message);
};

// ✅ BON - L'UI se met à jour
window.receiveFromSwift = (message) => {
	this.ngZone.run(() => {
		this.messages.push(message);
	});
};
```

### Cas d'usage

- 📍 Envoyer la position GPS
- 🔋 Informer sur l'état de la batterie
- 🔐 Transmettre un token d'authentification
- 📱 Notifier d'événements système iOS
- 🔔 Confirmer l'envoi d'une notification

---

## 📊 Résumé de l'Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        SwiftUI App                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   ┌─────────────────────────────────────────────────────┐   │
│   │              UIViewRepresentable                    │   │
│   │   ┌─────────────────────────────────────────────┐   │   │
│   │   │                WKWebView                    │   │   │
│   │   │                                             │   │   │
│   │   │    ┌─────────────────────────────────┐      │   │   │
│   │   │    │         Angular App             │      │   │   │
│   │   │    │                                 │      │   │   │
│   │   │    │  webkit.messageHandlers ──────────────────► Swift
│   │   │    │                                 │      │   │   │
│   │   │    │  window.receiveFromSwift ◄────────────────── Swift
│   │   │    │                                 │      │   │   │
│   │   │    └─────────────────────────────────┘      │   │   │
│   │   │                                             │   │   │
│   │   │    WKNavigationDelegate (guard routes)      │   │   │
│   │   │    WKScriptMessageHandler (messages)        │   │   │
│   │   └─────────────────────────────────────────────┘   │   │
│   └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔧 Fichiers de la Demo

| Fichier                  | Description              |
| ------------------------ | ------------------------ |
| `Demo1App.swift`         | Point d'entrée de l'app  |
| `ContentView.swift`      | Vue principale SwiftUI   |
| `WebViewModel.swift`     | Logique et configuration |
| `WebViewContainer.swift` | WebView + Communication  |
| `demo-standalone.html`   | Version HTML de test     |
| `angular-demo/`          | Projet Angular complet   |

---

## ✅ Checklist de la Demo

- [ ] La WebView charge l'app Angular
- [ ] Les URLs autorisées s'affichent dans la WebView
- [ ] Les URLs bloquées s'ouvrent dans Safari
- [ ] Angular peut envoyer des messages à Swift
- [ ] Swift peut envoyer des messages à Angular
- [ ] L'UI Angular se met à jour immédiatement (NgZone)

---

## 📚 Ressources

- [WKWebView - Apple Documentation](https://developer.apple.com/documentation/webkit/wkwebview)
- [WKScriptMessageHandler](https://developer.apple.com/documentation/webkit/wkscriptmessagehandler)
- [WKNavigationDelegate](https://developer.apple.com/documentation/webkit/wknavigationdelegate)
- [UIViewRepresentable](https://developer.apple.com/documentation/swiftui/uiviewrepresentable)
