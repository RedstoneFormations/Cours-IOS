//
//  DEMO1Tests.swift
//  DEMO1Tests
//
//  Created by Rayan Mechety on 09/12/2025.
//

import Testing
@testable import DEMO1

struct DEMO1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
