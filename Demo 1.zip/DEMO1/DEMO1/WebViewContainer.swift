import SwiftUI
import WebKit

struct WebViewContainer: View {
    @ObservedObject var viewModel: WebViewModel
    @State private var messageToSend = ""
    @State private var webView: WKWebView?

    var body: some View {
        VStack(spacing: 0) {
            // Barre d'outils
            VStack(spacing: 12) {
                // Zone de saisie
                HStack(spacing: 8) {
                    TextField("Message pour Angular...", text: $messageToSend)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .onSubmit { sendMessageToAngular() }

                    Button(action: sendMessageToAngular) {
                        Image(systemName: "paperplane.fill")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(messageToSend.isEmpty ? Color.gray : Color.blue)
                            .cornerRadius(8)
                    }
                    .disabled(messageToSend.isEmpty)
                }

                // Boutons d'actions rapides
                HStack(spacing: 8) {
                    QuickActionButton(title: "Hello! 👋", color: .blue) {
                        sendMessage("Hello depuis Swift! 👋")
                    }
                    QuickActionButton(title: "GPS 📍", color: .green) {
                        sendMessage("Position: 48.8566° N, 2.3522° E")
                    }
                    QuickActionButton(title: "Token 🔐", color: .orange) {
                        sendMessage("Token: \(UUID().uuidString.prefix(8))")
                    }
                }

                // URL actuelle
                if !viewModel.currentURL.isEmpty {
                    Text(viewModel.currentURL)
                        .font(.caption)
                        .foregroundColor(.gray)
                        .lineLimit(1)
                }
            }
            .padding()
            .background(Color.gray.opacity(0.1))

            // WebView
            WebViewRepresentable(
                viewModel: viewModel,
                webViewRef: $webView
            )
        }
        .navigationTitle("Demo Angular")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Actions

    private func sendMessageToAngular() {
        guard !messageToSend.isEmpty else { return }
        sendMessage(messageToSend)
        messageToSend = ""
    }

    private func sendMessage(_ message: String) {
        guard let webView = webView else { return }

        let script = viewModel.createSendMessageScript(message)
        webView.evaluateJavaScript(script) { result, error in
            if let error = error {
                print("❌ Erreur d'envoi: \(error.localizedDescription)")
            } else {
                print("✅ Message envoyé: \(message)")
            }
        }
    }
}

// MARK: - Quick Action Button

struct QuickActionButton: View {
    let title: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.white)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(color)
                .cornerRadius(8)
        }
    }
}

// MARK: - WebView Representable

struct WebViewRepresentable: UIViewRepresentable {
    @ObservedObject var viewModel: WebViewModel
    @Binding var webViewRef: WKWebView?

    func makeCoordinator() -> Coordinator {
        Coordinator(viewModel: viewModel)
    }

    func makeUIView(context: Context) -> WKWebView {
        // Configuration
        let config = WKWebViewConfiguration()
        let userContentController = WKUserContentController()

        // Script d'injection pour permettre la communication Angular → Swift
        let bridgeScript = WKUserScript(
            source: """
            // Exposer la fonction sendToSwift pour Angular
            window.sendToSwift = function(message) {
                window.webkit.messageHandlers.swiftHandler.postMessage(message);
            };

            // Intercepter les postMessage
            window.addEventListener('message', function(event) {
                if (event.data && event.data.source === 'angular') {
                    window.webkit.messageHandlers.swiftHandler.postMessage(event.data.message);
                }
            });

            console.log('🔗 Bridge Swift initialisé');
            """,
            injectionTime: .atDocumentStart,
            forMainFrameOnly: false
        )

        userContentController.addUserScript(bridgeScript)
        userContentController.add(context.coordinator, name: "swiftHandler")

        config.userContentController = userContentController

        // Créer la WebView
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator

        // Sauvegarder la référence
        DispatchQueue.main.async {
            self.webViewRef = webView
        }

        // Charger l'URL
        if let url = viewModel.startURL {
            if url.isFileURL {
                webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
            } else {
                webView.load(URLRequest(url: url))
            }
        }

        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        // Pas de mise à jour nécessaire
    }

    // MARK: - Coordinator

    class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        let viewModel: WebViewModel

        init(viewModel: WebViewModel) {
            self.viewModel = viewModel
        }

        // MARK: - WKScriptMessageHandler

        /// Reçoit les messages de JavaScript (Angular → Swift)
        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage
        ) {
            if message.name == "swiftHandler" {
                if let body = message.body as? String {
                    print("📥 Message d'Angular: \(body)")
                    viewModel.receiveMessageFromWeb(body)
                }
            }
        }

        // MARK: - WKNavigationDelegate

        /// Guard des routes - Intercepte les navigations
        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }

            // Vérifier si l'URL est autorisée
            if viewModel.isURLAllowed(url) {
                print("✅ Navigation autorisée: \(url.absoluteString)")
                decisionHandler(.allow)
            } else {
                // Ouvrir dans Safari
                print("🚫 Navigation bloquée, ouverture dans Safari: \(url.absoluteString)")
                UIApplication.shared.open(url)
                decisionHandler(.cancel)

                // Notifier
                viewModel.receiveMessageFromWeb("⚠️ URL bloquée → Safari: \(url.host ?? url.absoluteString)")
            }
        }

        /// Page chargée
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async {
                self.viewModel.isWebViewLoaded = true
                self.viewModel.currentURL = webView.url?.absoluteString ?? ""
            }

            // Récupérer le titre de la page
            webView.evaluateJavaScript("document.title") { result, _ in
                if let title = result as? String, !title.isEmpty {
                    print("📄 Page chargée: \(title)")
                    self.viewModel.receiveMessageFromWeb("✅ Page chargée: \(title)")
                }
            }
        }

        /// Erreur de chargement
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            print("❌ Erreur de navigation: \(error.localizedDescription)")
            viewModel.receiveMessageFromWeb("❌ Erreur: \(error.localizedDescription)")
        }
    }
}
