# DEMO 1: Intégration Angular avec SwiftUI

## 📋 Objectifs

Cette démo illustre la **communication bidirectionnelle** entre une application Angular et SwiftUI via WKWebView:

1. ✅ **Embed Site Externe**: Afficher Angular dans SwiftUI
2. 🛡️ **Guard Routes**: Bloquer certaines URLs → ouvrir dans Safari
3. 📤 **Angular → Swift**: Envoyer des événements d'Angular vers Swift
4. 📲 **Swift → Angular**: Envoyer des événements de Swift vers Angular

---

## 📁 Structure du Projet

```
Demo1-AngularSwiftUI/
├── Demo1App.swift           # Point d'entrée SwiftUI
├── ContentView.swift        # Vue principale
├── WebViewModel.swift       # Logique et configuration
├── WebViewContainer.swift   # WebView + Communication
├── demo-standalone.html     # Version HTML sans build Angular
└── angular-demo/            # Projet Angular complet
    ├── src/
    │   ├── app/
    │   │   ├── components/
    │   │   │   ├── home/
    │   │   │   ├── swift-to-angular/
    │   │   │   ├── angular-to-swift/
    │   │   │   └── route-guard-demo/
    │   │   └── services/
    │   │       └── swift-bridge.service.ts
    │   └── styles.css
    └── package.json
```

---

## 🚀 Comment Utiliser

### Option 1: Demo Rapide (HTML Standalone)

1. Créer un projet Xcode (SwiftUI App)
2. Copier les fichiers Swift dans le projet
3. Ajouter `demo-standalone.html` aux ressources
4. Lancer l'app

### Option 2: Avec Angular Complet

```bash
# 1. Installer les dépendances
cd angular-demo
npm install

# 2. Lancer le serveur de développement
npm start
# → http://localhost:4200

# 3. Dans WebViewModel.swift, utiliser:
var startURL: URL? {
    return URL(string: "http://localhost:4200")
}
```

---

## 🔧 Architecture

### Côté Swift

```
┌─────────────────────────────────────────────────┐
│                   SwiftUI App                    │
├─────────────────────────────────────────────────┤
│  ContentView                                     │
│  └── WebViewContainer                            │
│       └── WKWebView                              │
│            ├── WKScriptMessageHandler (receive) │
│            └── evaluateJavaScript (send)        │
├─────────────────────────────────────────────────┤
│  WebViewModel                                    │
│  └── messagesFromWeb[]                          │
│  └── allowedDomains[]                           │
└─────────────────────────────────────────────────┘
```

### Côté Angular

```
┌─────────────────────────────────────────────────┐
│                  Angular App                     │
├─────────────────────────────────────────────────┤
│  SwiftBridgeService                              │
│  ├── sendToSwift(message)                       │
│  │    └── webkit.messageHandlers.postMessage    │
│  └── receiveFromSwift(message)                  │
│       └── window.receiveFromSwift               │
└─────────────────────────────────────────────────┘
```

---

## 📤 Angular → Swift

### Angular (TypeScript)

```typescript
// service: swift-bridge.service.ts
sendToSwift(message: string): void {
  if (window.webkit?.messageHandlers?.swiftHandler) {
    window.webkit.messageHandlers.swiftHandler.postMessage(message);
  }
}
```

### Swift

```swift
// WKScriptMessageHandler
func userContentController(
    _ controller: WKUserContentController,
    didReceive message: WKScriptMessage
) {
    if let body = message.body as? String {
        print("Message d'Angular: \(body)")
        viewModel.receiveMessageFromWeb(body)
    }
}
```

---

## 📲 Swift → Angular

### Swift

```swift
// Envoyer un message
let script = "window.receiveFromSwift('Hello!')"
webView.evaluateJavaScript(script) { result, error in
    if let error = error {
        print("Erreur: \(error)")
    }
}
```

### Angular (TypeScript)

```typescript
// Exposer la fonction globale
window.receiveFromSwift = (message: string) => {
	console.log("Message de Swift:", message);
	// Traiter le message...
};
```

---

## 🛡️ Guard des Routes

### Configuration des domaines autorisés

```swift
let allowedDomains = [
    "angular.io",
    "localhost",
    "127.0.0.1"
]
```

### Interception de la navigation

```swift
func webView(
    _ webView: WKWebView,
    decidePolicyFor navigationAction: WKNavigationAction,
    decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
) {
    guard let url = navigationAction.request.url else {
        decisionHandler(.cancel)
        return
    }

    if isURLAllowed(url) {
        decisionHandler(.allow)    // Afficher dans WebView
    } else {
        UIApplication.shared.open(url)  // Ouvrir dans Safari
        decisionHandler(.cancel)
    }
}
```

---

## 🎯 Cas d'Usage

### Angular → Swift

- 📞 Déclencher un appel téléphonique
- 🔔 Demander une notification
- 📷 Ouvrir la caméra
- 💾 Sauvegarder dans Keychain

### Swift → Angular

- 📍 Envoyer la position GPS
- 🔋 Informer sur l'état batterie
- 🔐 Transmettre un token
- 📱 Notifier d'événements système

### Guard Routes

- 🔒 Bloquer les sites non autorisés
- 🌐 Ouvrir les liens externes dans Safari
- 📊 Logger les tentatives de navigation

---

## ⚙️ Configuration Info.plist

Pour charger des URLs HTTP (développement):

```xml
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsArbitraryLoads</key>
    <true/>
</dict>
```

---

## 🧪 Tests

### Sur Simulateur

1. Lancer l'app
2. Ouvrir la WebView
3. Tester l'envoi de messages dans les deux sens
4. Cliquer sur des liens pour tester le guard

### Messages Prédéfinis

- Swift: "Hello! 👋", "GPS 📍", "Token 🔐"
- Angular: "Login Event", "Click Event", "Data Update"

---

## 📚 Concepts Clés

| Concept                | Swift                    | Angular                   |
| ---------------------- | ------------------------ | ------------------------- |
| Afficher le web        | `WKWebView`              | -                         |
| Recevoir messages      | `WKScriptMessageHandler` | `window.receiveFromSwift` |
| Envoyer messages       | `evaluateJavaScript`     | `webkit.messageHandlers`  |
| Intercepter navigation | `WKNavigationDelegate`   | -                         |
| Injecter JS            | `WKUserScript`           | -                         |

---

## 🔗 Ressources

- [WKWebView Documentation](https://developer.apple.com/documentation/webkit/wkwebview)
- [WKScriptMessageHandler](https://developer.apple.com/documentation/webkit/wkscriptmessagehandler)
- [WKNavigationDelegate](https://developer.apple.com/documentation/webkit/wknavigationdelegate)
