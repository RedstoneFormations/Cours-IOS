import SwiftUI

struct ContentView: View {
    @StateObject private var webViewModel = WebViewModel()

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Header
                VStack(spacing: 15) {
                    Text("🔗 Angular + SwiftUI")
                        .font(.title)
                        .bold()

                    Text("Communication bidirectionnelle via WKWebView")
                        .font(.subheadline)
                        .foregroundColor(.gray)

                    // Status de connexion
                    HStack {
                        Circle()
                            .fill(webViewModel.isWebViewLoaded ? Color.green : Color.red)
                            .frame(width: 10, height: 10)
                        Text(webViewModel.isWebViewLoaded ? "WebView chargée" : "En attente...")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(20)
                }
                .padding()

                // Navigation vers la WebView
                NavigationLink(destination: WebViewContainer(viewModel: webViewModel)) {
                    HStack {
                        Image(systemName: "globe")
                        Text("Ouvrir la Demo Angular")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(LinearGradient(
                        colors: [Color.blue, Color.purple],
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .cornerRadius(12)
                }
                .padding(.horizontal)

                // Messages reçus d'Angular
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("📥 Messages d'Angular")
                            .font(.headline)
                        Spacer()
                        if !webViewModel.messagesFromWeb.isEmpty {
                            Button(action: { webViewModel.clearMessages() }) {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                            }
                        }
                    }

                    if webViewModel.messagesFromWeb.isEmpty {
                        Text("Aucun message reçu")
                            .foregroundColor(.gray)
                            .italic()
                            .padding(.vertical)
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 8) {
                                ForEach(webViewModel.messagesFromWeb, id: \.self) { message in
                                    HStack {
                                        Text(message)
                                            .font(.system(.body, design: .monospaced))
                                        Spacer()
                                    }
                                    .padding(10)
                                    .background(Color.green.opacity(0.1))
                                    .cornerRadius(8)
                                }
                            }
                        }
                        .frame(maxHeight: 200)
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.05))
                .cornerRadius(12)
                .padding()

                Spacer()

                // Info
                VStack(spacing: 5) {
                    Text("💡 Ouvrez la WebView et utilisez les boutons")
                    Text("pour envoyer des messages dans les deux sens")
                }
                .font(.caption)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding()
            }
            .navigationBarHidden(true)
        }
    }
}
