import SwiftUI

@main
struct Demo1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
