import Foundation
import WebKit
import Combine

class WebViewModel: ObservableObject {
    // MARK: - Published Properties

    @Published var messagesFromWeb: [String] = []
    @Published var isWebViewLoaded = false
    @Published var currentURL: String = ""

    // MARK: - Configuration

    /// URLs autorisées dans la WebView
    /// Les autres URLs s'ouvriront dans Safari
    let allowedDomains = [
		"angular.io",
		"angular.dev",
        "localhost",
        "127.0.0.1",
		"http://localhost:4200/"
    ]

    /// URL de démarrage
    /// Option 1: Serveur local Angular (npm start)
    /// Option 2: Fichier HTML local
    var startURL: URL? {
        // Option 1: Serveur de développement Angular
         return URL(string: "http://localhost:4200")

        // Option 2: Fichier HTML standalone (pour demo rapide)
//        return Bundle.main.url(forResource: "demo-standalone", withExtension: "html")
    }

    // MARK: - URL Validation

    /// Vérifie si une URL est autorisée dans la WebView
    func isURLAllowed(_ url: URL) -> Bool {
        guard let host = url.host else {
            // URLs locales (file://) sont autorisées
            return url.scheme == "file"
        }
        return allowedDomains.contains { host.contains($0) }
    }

    // MARK: - Communication Angular → Swift

    /// Reçoit un message de la page web (Angular)
    func receiveMessageFromWeb(_ message: String) {
        DispatchQueue.main.async {
            let timestamp = Self.formatTimestamp()
            self.messagesFromWeb.insert("[\(timestamp)] \(message)", at: 0)

            // Limiter à 50 messages
            if self.messagesFromWeb.count > 50 {
                self.messagesFromWeb.removeLast()
            }
        }
    }

    // MARK: - Communication Swift → Angular

    /// Génère le JavaScript pour envoyer un message à Angular
    func createSendMessageScript(_ message: String) -> String {
        // Échapper les caractères spéciaux
        let escapedMessage = message
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
            .replacingOccurrences(of: "\n", with: "\\n")

        return """
        (function() {
            // Méthode 1: Fonction globale (préféré)
            if (window.receiveFromSwift) {
                window.receiveFromSwift('\(escapedMessage)');
                return 'sent via receiveFromSwift';
            }
            // Méthode 2: PostMessage
            window.postMessage({source: 'swift', data: '\(escapedMessage)'}, '*');
            return 'sent via postMessage';
        })();
        """
    }

    // MARK: - Message Management

    func clearMessages() {
        messagesFromWeb.removeAll()
    }

    // MARK: - Helpers

    private static func formatTimestamp() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: Date())
    }
}
